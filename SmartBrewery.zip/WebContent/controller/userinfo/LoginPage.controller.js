sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController', 'sap/ui/model/json/JSONModel',
	"sap/ui/VersionInfo", "sap/ui/core/mvc/XMLView", 'sap/m/MessageBox', 'sap/m/MessageToast'
], function (
	BaseController, JSONModel, VersionInfo, XMLView, MessageBox, MessageToast) {
	"use strict";
	var flag = false;
	return BaseController.extend("SmartBrewer.RegistProject.controller.userinfo.LoginPage", {

		onInit: function () {
			var oModel = new JSONModel();
			sap.ui.getCore().setModel(oModel);
			var appData = {
				id: null
			};
			console.log(sap.ui.getCore().getModel().getProperty('/appData'));

		},

		login: function () {
			var oModel = new JSONModel();
			var jsonData = {};
			sap.ui.getCore().setModel(oModel);
			oModel.setData(jsonData);

			var id = this.getView().byId("getid").getValue();
			var pw = this.getView().byId("getpw").getValue();

			//통신부
			$.ajax({
				url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify({
					importData: {
						I_USERID: id,
						I_USERPW: pw
					},
					function: "ZB_GET_USERID"
				}),
				dataType: 'json',
				success: function (res) {
					var E_USERID = res.exportData.E_USERID;
					var E_USERTY = res.exportData.E_USERTY;
					var E_CODE = res.exportData.E_CODE;
					var E_USERNM = res.exportData.E_USERNM;
					var E_USERNI = res.exportData.E_USERNI;
					var userData = {
						E_USERID: E_USERID,
						E_USERTY: E_USERTY,
						E_CODE: E_CODE
					};
					console.log(userData.E_CODE);
					if (userData.E_CODE === 'S') {
						localStorage.setItem("UserId", E_USERID);
						localStorage.setItem("UserType", E_USERTY);
						localStorage.setItem("LoginCode", E_CODE);
						localStorage.setItem("UserName", E_USERNM);
						localStorage.setItem("UserNickName", E_USERNI);
						flag = true;
					}
					sap.ui.getCore().getModel().setProperty('/userData', userData);
				},
				error: function (e) {}
			});
			setTimeout(() => {
				this.registButton();
			}, 1000)

		},

		registButton: function () {
			var self = this;
			console.log(flag);
			if (flag === true) {
				var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;
				self.getRouter().navTo("home");
				sap.m.MessageBox.show(
					'환영합니다!', {
						title: "로그인",
						actions: [sap.m.MessageBox.Action.CLOSE],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							self.getLoginSet();
							window.location.reload();
						}
					}
				);
			} else {
				MessageBox.show("아이디 또는 비밀번호를 확인하세요.")
				flag = false;
			}

		},

		getLoginSet: function () {
			console.log(localStorage.getItem("LoginCode"));
			var oModel = this.getOwnerComponent().getModel('uiControl');
			if (localStorage.getItem("LoginCode") === "S") {
				if (oModel) {
					if (localStorage.getItem("UserType") !== "A") {
						oModel.setData({
							visibleLoginButton: false,
							visibleUserButton: true,
							visibleAdminflag: false
						});
					} else {
						oModel.setData({
							visibleLoginButton: false,
							visibleUserButton: true,
							visibleAdminflag: true
						});
					}
					sap.ui.getCore().byId("container-RegistProject---app--userButton").setText(localStorage.getItem("UserName") + "(" + localStorage.getItem(
						"UserNickName") + ")");
				}
			} else {
				localStorage.setItem("UserId", "");
				if (oModel) {
					oModel.setData({
						visibleLoginButton: true,
						visibleUserButton: false,
						visibleAdminflag: false
					});
				}
			}
		},

		btnClicked: function () {
			this.getRouter().navTo("userregist");
		}

		//   console.log(this.getUserId());

	});

});