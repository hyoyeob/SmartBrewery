sap.ui.define([
	"SmartBrewer/RegistProject/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView"
], function (BaseController, JSONModel, MessageBox, VersionInfo, XMLView) {
	"use strict";
	var A = "";
	var eflag;
	var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";
	return BaseController.extend("SmartBrewer.RegistProject.controller.userinfo.UserRegist", {
		onClick: function () {},
		onInit: function () {
			var model = new sap.ui.model.json.JSONModel();
			var data = [{
				USERTY: "N",
				USERNM: "N",
				test: "Group A"
			}, {
				USERTY: "P",
				USERNM: "P",
				test: "Group A"
			}];
			model.setData(data);
			this.getView().setModel(model);
		},
		urlRuleCheck: function (oEvent) {
			var newValue = oEvent.getSource().getValue();
			var regExp = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
			var sState = regExp.test(newValue) ? "None" : "Warning";
			oEvent.getSource().setValueState(sState);
			if (sState === "Warning") {
				eflag = true;
			} else {
				eflag = false;
			}
		},
		phoneRuleCheck: function (oEvent) {
			var newValue = oEvent.getSource().getValue();
			var regExp = /(01[016789])-([1-9]{1}[0-9]{2,3})-([0-9]{4})$/;
			var sState = regExp.test(newValue) ? "None" : "Warning";
			console.log(newValue);
			oEvent.getSource().setValueState(sState);
			if (sState === "Warning") {
				eflag = true;
			} else {
				eflag = false;
			}
		},
		emailRuleCheck: function (oEvent) {
			console.log(this.getUserId());
			var newValue = oEvent.getSource().getValue();
			var regExp = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
			var sState = regExp.test(newValue) ? "None" : "Warning";
			oEvent.getSource().setValueState(sState);
			if (sState === "Warning") {
				eflag = true;
			} else {
				eflag = false;
			}
		},
		TextLengthCheck: function (oEvent) {
			var newValue = oEvent.getParameter("value").length;
			var iMaxLength = oEvent.getSource().getMaxLength();
			var sState = newValue > iMaxLength ? "Warning" : "None";
			oEvent.getSource().setValueState(sState); // this.byId('getValue').setText(newValue + "/" + iMaxLength);
			if (sState === "Warning") {
				eflag = true;
			} else {
				eflag = false;
			}
		},
		minLengthCheck: function (oEvent) {
			var newValue = oEvent.getParameter("value").length;
			var iMaxLength = oEvent.getSource().getMaxLength();
			var sState = newValue < iMaxLength ? "Warning" : "None";
			oEvent.getSource().setValueState(sState); // this.byId('getValue').setText(newValue + "/" + iMaxLength);
			if (sState === "Warning") {
				eflag = true;
			} else {
				eflag = false;
			}
		},
		onSave: function (oEvent) {
			var self = this;
			console.log(this.getView().byId("usertyInput").getSelectedKey());
			var E_MSG;
			var E_RESULT;
			var I_REGFLG = this.getView().getModel().getProperty('/regflg');
			console.log(this.getView().getModel());
			if (eflag === true) {
				MessageBox.show("입력 양식이 올바르지 않습니다.");
			} else {
				$.ajax({
					url: rfc_url,
					type: "POST",
					contentType: "application/json",
					data: JSON.stringify({
						importData: {
							"I_USERID": this.getView().byId("IDInput").getValue(),
							"I_USERPW": this.getView().byId("PasswordInput").getValue(),
							"I_USERNM": this.getView().byId("NameInput").getValue(),
							"I_USERTL": this.getView().byId("TELInput").getValue(),
							"I_USERNI": this.getView().byId("NickNameInput").getValue(),
							"I_USERMA": this.getView().byId("MailInput").getValue(),
							"I_USERTY": this.getView().byId("usertyInput").getValue(),
							"I_USERYR": this.getView().byId("BirthDateInput").getValue(),
							"I_REGFLG": I_REGFLG //모델 바인딩 혹은 전역 변수에서 체크펑션 결과 받아옴
						},
						function: "ZB_GET_USER_SAVE"
					}),
					dataType: "json",
					success: function (res) {
						console.log(res, I_REGFLG);
						E_MSG = res.exportData.E_MSG;
						E_RESULT = res.exportData.E_RESULT;
						// MessageBox.show("아이디 중복검사를 해주세요.");

						if (E_RESULT === "S") {
							console.log("성공일 때")
							MessageBox.show(E_MSG);
							self.getRouter().navTo("loginpage");
						} else {
							console.log("실패일 때")
							MessageBox.show(E_MSG);
						}

					},
					error: function (e) {
						MessageToast.show(e);
					}
				}); /*   this.getView().setModel(oModel2,"f");*/
			}

		},
		btnClicked: function (oEvent) {
			var self = this;
			var checkUserid = self.getView().byId("IDInput").getValue();
			console.log(checkUserid);
			console.log(this.getView().byId("usertyInput").getSelectedKey());
			$.ajax({
				url: rfc_url,
				type: "POST",
				contentType: "application/json",
				data: JSON.stringify({
					importData: {
						"I_USERID": checkUserid
					},
					function: "ZB_GET_USERID_CHECK"
				}),
				dataType: "json",
				success: function (res) {
					let E_MSG = res.exportData.E_MSG;
					let E_REGFLG = res.exportData.E_REGFLG;
					let E_RESULT = res.exportData.E_RESULT;
					self.getView().getModel().setProperty('/regflg', E_REGFLG);

					// RFC 결과 메세지박스 
					var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;
					if (E_RESULT == "E") {
						MessageBox.alert("아이디 중복검사를 해주세요.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						});
					} else {
						if (E_REGFLG == "X") {
							self.getView().byId("IDInput").setEditable(false);
							MessageBox.success("사용가능한 아이디입니다.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});
						} else {

							MessageBox.alert("이미 존재하는 아이디입니다.", {
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							});
						}
					}

					A = res.exportData.E_REGFLG;
					console.log(res.exportData.E_REGFLG);
				},
				error: function (e) {
					MessageToast.show(e);
				}
			});

		},

		/**
		 *@memberOf SmartBrewer.RegistProject.controller.userinfo.UserRegist
		 */
		action: function (oEvent) {
			var that = this;
			var actionParameters = JSON.parse(oEvent.getSource().data("wiring").replace(/'/g, "\""));
			var eventType = oEvent.getId();
			var aTargets = actionParameters[eventType].targets || [];
			aTargets.forEach(function (oTarget) {
				var oControl = that.byId(oTarget.id);
				if (oControl) {
					var oParams = {};
					for (var prop in oTarget.parameters) {
						oParams[prop] = oEvent.getParameter(oTarget.parameters[prop]);
					}
					oControl[oTarget.action](oParams);
				}
			});
			var oNavigation = actionParameters[eventType].navigation;
			if (oNavigation) {
				var oParams = {};
				(oNavigation.keys || []).forEach(function (prop) {
					oParams[prop.name] = encodeURIComponent(JSON.stringify({
						value: oEvent.getSource().getBindingContext(oNavigation.model).getProperty(prop.name),
						type: prop.type
					}));
				});
				if (Object.getOwnPropertyNames(oParams).length !== 0) {
					this.getOwnerComponent().getRouter().navTo(oNavigation.routeName, oParams);
				} else {
					this.getOwnerComponent().getRouter().navTo(oNavigation.routeName);
				}
			}

		}
	});
});