sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController', 'sap/ui/model/json/JSONModel', 'sap/m/MessageBox',
	'sap/m/MessageToast', "sap/ui/VersionInfo", "sap/ui/core/mvc/XMLView"
], function (
	BaseController, JSONModel, MessageBox, MessageToast, VersionInfo, XMLView) {
	"use strict";
	var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";

	return BaseController.extend("SmartBrewer.RegistProject.controller.userinfo.UserInfoModify", {

		onInit: function () {
			sap.ui.getCore().getModel("appModel").setProperty('/id', this.getUserId());
			var model = sap.ui.getCore().getModel("appModel")
			this.setModel(model, "appModel");

			var id = sap.ui.getCore().getModel("appModel").getProperty('/id');

			var model = new sap.ui.model.json.JSONModel();

			// rfc
			let jsonData = {};

			var data = [{
				USERTY: "N",
				USERNM: "N(고객)",
				test: "Group A"
			}, {
				USERTY: "P",
				USERNM: "P(사업자)",
				test: "Group A"
			}];
			model.setData(data);

			this.getView().setModel(model);

			// 데이터 불러오기ㅣㅣㅣㅣ

			var self = this;
			let E_MSG;
			let E_RESULT;
			$.ajax({
				url: rfc_url,
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify({
					importData: {
						"I_USERID": id
					},
					function: "ZB_GET_USER_INQUIRY"
				}),
				dataType: 'json',
				success: function (res) {
					console.log(res);
					console.log(res)
					let rfcData = {
						E_USERID: res.exportData.E_USERID,
						E_USERNM: res.exportData.E_USERNM,
						E_USERYR: res.exportData.E_USERYR,
						E_USERTL: res.exportData.E_USERTL,
						E_USERMA: res.exportData.E_USERMA,
						E_USERNI: res.exportData.E_USERNI,
						E_USERTY: res.exportData.E_USERTY,
						E_RESULT: res.exportData.E_RESULT,
						E_MSG: res.exportData.E_MSG
					}
					self.getView().byId("NameInput").setText(res.exportData.E_USERNM);
					self.getView().byId("TELInput").setValue(res.exportData.E_USERTL);
					self.getView().byId("NickNameInput").setValue(res.exportData.E_USERNI);
					self.getView().byId("MailInput").setValue(res.exportData.E_USERMA);
					self.getView().byId("BirthDateInput").setValue(res.exportData.E_USERYR);

					//
					console.log(res.exportData.E_USERTY);

					if (res.exportData.E_USERTY == "N") {
						self.getView().byId("userType").setText("N(고객)");
					} else {
						self.getView().byId("userType").setText("P(사업자)");
					}

					// self.getView().byId("userType").setText(res.exportData.E_USERTY);
					// self.getModel().setProperty("/rfcData", rfcData);
					console.log(self.getModel().getProperty("/rfcData"));
					self.getModel().setProperty("/rfcData", rfcData);
					// MessageBox.show(res.exportData.E_MSG)
				},
				error: function (e) {
					MessageToast.show(e);
				}
			});
			console.log(this)
		},

		urlRuleCheck: function (oEvent) {
			var newValue = oEvent.getSource().getValue();
			var regExp = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
			var sState = regExp.test(newValue) ? "None" : "Warning";
			oEvent.getSource().setValueState(sState);

		},

		phoneRuleCheck: function (oEvent) {
			var newValue = oEvent.getSource().getValue();
			var regExp = /(01[016789])-([1-9]{1}[0-9]{2,3})-([0-9]{4})$/;
			var sState = regExp.test(newValue) ? "None" : "Warning";
			console.log(newValue);
			oEvent.getSource().setValueState(sState);
		},

		emailRuleCheck: function (oEvent) {
			var newValue = oEvent.getSource().getValue();
			var regExp = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
			var sState = regExp.test(newValue) ? "None" : "Warning";
			oEvent.getSource().setValueState(sState);
		},

		TextLengthCheck: function (oEvent) {
			var newValue = oEvent.getParameter("value").length;
			var iMaxLength = oEvent.getSource().getMaxLength();
			var sState = newValue > iMaxLength ? "Warning" : "None";
			oEvent.getSource().setValueState(sState);
			// this.byId('getValue').setText(newValue + "/" + iMaxLength);
		},

		minLengthCheck: function (oEvent) {
			var newValue = oEvent.getParameter("value").length;
			var iMaxLength = oEvent.getSource().getMaxLength();
			var sState = newValue < iMaxLength ? "Warning" : "None";
			oEvent.getSource().setValueState(sState);
			// this.byId('getValue').setText(newValue + "/" + iMaxLength);
		},

		// onSave : function(oEvent){
		//    let pw = this.byId('PasswordInput').getValue()
		//    let pw2 = this.byId('PasswordInput2').getValue()

		//    console.log(pw)
		//    console.log(pw2)

		//    if(pw !== pw2){
		//       alert('동일한 패스워드를 입력해주세요!')
		//    }else{
		//       if(pw.length < 8 || pw2.length < 8){
		//          alert('패스워드는 8자 이상 해주세요')
		//       }
		//    }
		// }

		onSave: function (oEvent) {
			var pw = this.byId('PasswordInput').getValue();
			var pw2 = this.byId('PasswordInput2').getValue();

			if (pw !== pw2) {
				MessageBox.show('올바른 비밀번호를 입력해주세요.');
				return;
			} else {
				if (pw.length < 8 || pw2.length < 8) {
					MessageBox.show('패스워드는 8자 이상 해주세요.');
					return;
				}

				if (pw == pw2) {
					var self = this;
					let E_MSG;
					let E_RESULT;
					$.ajax({
						url: rfc_url,
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_USERID: this.getView().byId("UserId").getText(),
								I_USERPW: this.getView().byId("PasswordInput").getValue(),
								I_USERNM: this.getView().byId("NameInput").getText(),
								I_USERTL: this.getView().byId("TELInput").getValue(),
								I_USERNI: this.getView().byId("NickNameInput").getValue(),
								I_USERMA: this.getView().byId("MailInput").getValue(),
								I_USERTY: this.getView().byId("userType").getText(),
								I_USERYR: this.getView().byId("BirthDateInput").getValue(),
								I_REGFLG: "X"

							},
							function: "ZB_GET_USER_SAVE"
						}),
						dataType: 'json',
						success: function (res) {
							E_MSG = res.exportData.E_MSG;
							E_RESULT = res.exportData.E_RESULT;

							if (res.exportData.E_RESULT === 'E') {
								MessageBox.show(E_MSG);
							} else {
								var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;
								sap.m.MessageBox.show(
									E_MSG, {
										title: "경고",
										actions: [sap.m.MessageBox.Action.CLOSE],
										styleClass: bCompact ? "sapUiSizeCompact" : "",
										initialFocus: "Sign in",
										onClose: function (sAction) {
											if (sAction === "CLOSE") {
												self.getRouter().navTo("home");
												window.location.reload();
												return;
											}
										}
									}
								);
							}
						},
						error: function (e) {
							MessageBox.show(e);
						}
					});
					/*   this.getView().setModel(oModel2,"f");*/
				}
			}
		},
		oncancel: function () {
			this.getRouter().navTo("home");
		}
	});

});