sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent", 'sap/ui/model/json/JSONModel', 'sap/m/MessageBox'
], function (Controller, UIComponent, JSONModel, MessageBox) {
	"use strict";
	var _timeout;
	return Controller.extend("SmartBrewer.RegistProject.controller.BaseController", {

		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},

		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},
		getUser: function () { //임시 로그인 처리 함수
			var oModel = new JSONModel();
			sap.ui.getCore().setModel(oModel);

			//통신부
			$.ajax({
				url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify({
					importData: {
						I_USERID: "TESTING",
						I_USERPW: "00000000"
					},
					function: "ZB_GET_USERID"
				}),
				dataType: 'json',
				success: function (res) {
					console.log(res)
					var E_USERID = res.exportData.E_USERID;
					var E_USERTY = res.exportData.E_USERTY;
					var E_CODE = res.exportData.E_CODE;
					var userData = {
						E_USERID: E_USERID,
						E_USERTY: E_USERTY,
						E_CODE: E_CODE
					};
					sap.ui.getCore().getModel().setProperty('/userData', userData);
				},
				error: function (e) {}
			});
		},
		getUserId: function () {
			return localStorage.getItem("UserId");
		},
		getUserType: function () {
			return localStorage.getItem("UserType");
			// try {
			// 	return sap.ui.getCore().getModel().getProperty('/userData').E_USERTY;
			// } catch (e) {
			// 	return null;
			// }
		},

		getLoginCode: function () {
			return localStorage.getItem("LoginCode");
		},
		UserReset: function () {
			localStorage.setItem("UserId", "");
			localStorage.removeItem("UserType");
			localStorage.removeItem("LoginCode");
			localStorage.removeItem("UserName");
			localStorage.removeItem("UserNickName");
		},
		onOpenDialog: function (oEvent) {
			// instantiate dialog
			if (!this._dialog) {
				this._dialog = sap.ui.xmlfragment("SmartBrewer.RegistProject.view.BusyDialog", this);
				this.getView().addDependent(this._dialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
			this._dialog.open();
			_timeout = jQuery.sap.delayedCall(300, this, function () {
				this._dialog.close();
			});
		},
		LoginCheckDialog: function (state) {
			var self = this;
			if (this.getLoginCode() === "S") {
				state = true;
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.show(
					'로그인이 필요한 서비스입니다.', {
						title: "로그인",
						actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						initialFocus: "Sign in",
						onClose: function (sAction) {
							if (sAction === "로그인") {
								self.getRouter().navTo("loginpage");
							} else {
								state = false;
							}
						}
					}
				);
			}
		}
	});

});