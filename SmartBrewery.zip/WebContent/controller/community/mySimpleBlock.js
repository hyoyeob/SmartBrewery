sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	return BlockBase.extend("SmartBrewer.RegistProject.controller.community.mySimpleBlock", {
		metadata: {
			/* no additional views provided */
		}
	});
}, true);