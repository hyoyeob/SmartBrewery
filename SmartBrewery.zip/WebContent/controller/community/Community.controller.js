sap.ui.define([
		"SmartBrewer/RegistProject/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/m/Dialog",
		"sap/m/Button",
		"sap/m/Text",
		"sap/m/Input",
		"sap/m/Label",
		"sap/m/TextArea",
		"sap/ui/VersionInfo",
		"sap/ui/core/mvc/XMLView",
		"sap/ui/model/Filter",
		"sap/m/MessageToast",
		"sap/m/MessageBox"
	],
	function (BaseController, JSONModel, Dialog, Button, Text, Input, Label, TextArea, VersionInfo, XMLView, Filter, MessageToast, MessageBox) {
		"use strict";

		var index = 1;

		return BaseController.extend("SmartBrewer.RegistProject.controller.community.Community", {
			onInit: function () {
				this.getUser();
				var self = this;
				console.log(self);
				var oModel = new JSONModel()
				let jsonData = {
					rfcData: {
						E_MSG: [],
						E_RESULT: [],
						T_OLIST: [],
						ALLPOST: []
					},
					layoutData: {
						I_REVINM: "",
						I_REVICO: "",
					},
					otherData: {
						POSTID: ""
					}
				};
				$.ajax({
					url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_PAGEIDX: index
						},
						function: "ZB_GET_COMMUNITY_COMMENT01"
					}),
					dataType: 'json',
					success: function (res) {
						let ALLPOST = res.exportData.EXPORT_ALLPOST;
						let rfcData = {
							ALLPOST: ALLPOST,
							PAGECNT: res.exportData.E_PAGECNT
						}
						self.getModel().setProperty('/rfcData', rfcData);
						self.getView().byId("pageidx").setText(index + "/" + self.getModel().getProperty('/rfcData/PAGECNT'));
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});
				this.setModel(oModel);
				oModel.setData(jsonData);
			},

			previous: function () {
				var self = this;
				if (index != 1) {
					index -= 1;
					$.ajax({
						url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_PAGEIDX: index
							},
							function: "ZB_GET_COMMUNITY_COMMENT01"
						}),
						dataType: 'json',
						success: function (res) {
							let ALLPOST = res.exportData.EXPORT_ALLPOST;
							let rfcData = {
								ALLPOST: ALLPOST,
								PAGECNT: res.exportData.E_PAGECNT
							}
							self.getModel().setProperty('/rfcData', rfcData);
							self.getView().byId("pageidx").setText(index + "/" + self.getModel().getProperty('/rfcData/PAGECNT'));
						},
						error: function (e) {
							MessageToast.show(e);
						}
					});
				} else {
					MessageToast.show("첫 페이지입니다.");
				}
			},

			next: function () {
				var self = this;
				var max = self.getModel().getProperty('/rfcData/PAGECNT');
				console.log(self.getModel());
				if (index != max) {
					index += 1;
					console.log(index);
					$.ajax({
						url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_PAGEIDX: index
							},
							function: "ZB_GET_COMMUNITY_COMMENT01"
						}),
						dataType: 'json',
						success: function (res) {
							let ALLPOST = res.exportData.EXPORT_ALLPOST;
							let rfcData = {
								ALLPOST: ALLPOST,
								PAGECNT: res.exportData.E_PAGECNT
							}
							self.getModel().setProperty('/rfcData', rfcData);
							self.getView().byId("pageidx").setText(index + "/" + self.getModel().getProperty('/rfcData/PAGECNT'));
						},
						error: function (e) {
							MessageToast.show(e);
						}
					});
				} else {
					MessageToast.show("마지막 페이지입니다.");
				}
			},

			//
			handleIconTabBarSelect: function (oEvent) {
				this.onOpenDialog();
				var sKey = oEvent.getParameter("key");
				var self = this;
				if (sKey == "onRegistPage") {
					var self = this;
					if (this.getLoginCode() !== "S") {
						var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
						sap.m.MessageBox.show(
							'로그인이 필요한 서비스입니다.', {
								title: "로그인",
								actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								initialFocus: "Sign in",
								onClose: function (sAction) {
									if (sAction === "로그인") {
										self.getRouter().navTo("loginpage");
										window.location.reload();
									}
								}
							}
						);
					} else {
						this.getRouter().navTo("communityregist");
						window.location.reload();
					}
				}
			},

			// onRegistPage: function () {
			// 	var self = this;
			// 	if (this.getLoginCode() !== "S") {
			// 		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			// 		sap.m.MessageBox.show(
			// 			'로그인이 필요한 서비스입니다.', {
			// 				title: "로그인",
			// 				actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
			// 				styleClass: bCompact ? "sapUiSizeCompact" : "",
			// 				initialFocus: "Sign in",
			// 				onClose: function (sAction) {
			// 					if (sAction === "로그인") {
			// 						self.getRouter().navTo("loginpage");
			// 					}
			// 				}
			// 			}
			// 		);
			// 	} else {
			// 		this.getRouter().navTo("communityregist");
			// 	}
			// },

			action: function (oEvent) {
				var that = this;
				var actionParameters = JSON.parse(oEvent.getSource().data("wiring").replace(/'/g, "\""));
				var eventType = oEvent.getId();
				var aTargets = actionParameters[eventType].targets || [];
				aTargets.forEach(function (oTarget) {
					var oControl = that.byId(oTarget.id);
					if (oControl) {
						var oParams = {};
						for (var prop in oTarget.parameters) {
							oParams[prop] = oEvent.getParameter(oTarget.parameters[prop]);
						}
						oControl[oTarget.action](oParams);
					}
				});
				var oNavigation = actionParameters[eventType].navigation;
				if (oNavigation) {
					var oParams = {};
					(oNavigation.keys || []).forEach(function (prop) {
						oParams[prop.name] = encodeURIComponent(JSON.stringify({
							value: oEvent.getSource().getBindingContext(oNavigation.model).getProperty(prop.name),
							type: prop.type
						}));
					});
					if (Object.getOwnPropertyNames(oParams).length !== 0) {
						this.getOwnerComponent().getRouter().navTo(oNavigation.routeName, oParams);
					} else {
						this.getOwnerComponent().getRouter().navTo(oNavigation.routeName);
					}
				}
			},

			onsearch: function (oEvent) {
				var self = this;
				var sskey = oEvent.getSource().getValue();
				var flag = 'X';

				$.ajax({
					url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_PAGEIDX: index,
							I_FLAG: flag,
							I_KEY: sskey
						},
						function: "ZB_GET_COMMUNITY_COMMENT01"
					}),
					dataType: 'json',
					success: function (res) {
						let ALLPOST = res.exportData.EXPORT_ALLPOST;
						let rfcData = {
							ALLPOST: ALLPOST,
							PAGECNT: res.exportData.E_PAGECNT
						}
						self.getModel().setProperty('/rfcData', rfcData);
						self.getView().byId("pageidx").setText(index + "/" + self.getModel().getProperty('/rfcData/PAGECNT'));
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});

			},

			onItemSelect: function (oEvent) {
				let self = this
					// let selectedRow = oEvent.getSource().getBindingContext().getObject()

				var path = oEvent.getSource().getBindingContext().getPath();
				var selectedRow = this.byId('lineItemsList').getModel().getProperty(path);
				console.log(selectedRow.POSTID)
					// let selectedRow = oEvent.getSource().getItems();
				$.ajax({
					url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_POSTID: selectedRow.POSTID
						},
						function: "ZB_GET_COMMUNITY_COMMENT01"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						var oModel2 = new JSONModel(res.exportData);
						self.getOwnerComponent().setModel(oModel2, "ClickedList");
						console.log(self.getOwnerComponent().getModel("ClickedList"));
						self.getRouter().navTo("communityContent");
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});
			},

			onPost: function () {
				var self = this;
				if (this.getLoginCode() !== "S") {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.show(
						'로그인이 필요한 서비스입니다.', {
							title: "로그인",
							actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							initialFocus: "Sign in",
							onClose: function (sAction) {
								if (sAction === "로그인") {
									self.getRouter().navTo("loginpage");
								}
							}
						}
					);
				} else {
					var POSTID = this.getOwnerComponent().getModel("ClickedList").getProperty('/EXPORT_ALLPOST/0/POSTID')
					var USERID = this.getOwnerComponent().getModel("ClickedList").getProperty('/EXPORT_ALLPOST/0/USERID')
					var COMMCO = this.getView().byId("getComment").getValue();
					$.ajax({
						url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_POSTID: POSTID,
								I_USERID: self.getUserId(),
								I_COMMCO: COMMCO
							},
							function: "ZB_GET_FUNDING_COMMENT01"
						}),
						dataType: 'json',
						success: function (res) {
							var commandList = res.exportData;
							self.getOwnerComponent().setModel("ClickedList", commandList);
							var EXPORT_ALLPOST = self.getOwnerComponent().getModel("ClickedList").getProperty('/EXPORT_ALLPOST');
							self.getOwnerComponent().getModel("ClickedList").setData({
								EXPORT_ALLPOST: EXPORT_ALLPOST,
								EXPORT_COMMENT: res.exportData.EXPORT_COMMENT
							});
						},
						error: function (e) {
							MessageToast.show(e);
						}
					});
				}
			},
			test: function (oEvent) {
				console.log('click me?')
				console.log(oEvent.getSource().getBindingContext().getObject())
					// console.log(this)
					// console.log(this.getView().getModel("ClickedList"));
			}
		});
	});