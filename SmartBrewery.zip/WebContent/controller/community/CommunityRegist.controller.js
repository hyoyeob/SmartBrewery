sap.ui.define([
	"SmartBrewer/RegistProject/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text",
	"sap/m/Input",
	"sap/m/Label",
	"sap/m/TextArea",
	"sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView",
	"sap/ui/model/Filter",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, Dialog, Button, Text, Input, Label, TextArea, VersionInfo, XMLView, Filter, MessageBox) {
	"use strict";
	return BaseController.extend("SmartBrewer.RegistProject.controller.community.CommunityRegist", {
		onInit: function () {
			//테스트용 로그인
			var oModel = new JSONModel();
			let jsonData = {
				rfcData: {
					E_MSG: [],
					E_RESULT: [],
					T_OLIST: []
				},
				layoutData: {
					I_REVINM: "",
					I_REVICO: ""
				}
			};
			//모델생성
			this.setModel(oModel);
			//데이터 넣기
			this.getModel().setData(jsonData);
		},
		changeRevinm: function (oEvent) {
			let revinm = oEvent.getSource().getValue();
			this.getModel().setProperty("/layoutData/I_REVINM", revinm);
		},
		changeRevico: function (oEvent) {
			let revico = oEvent.getSource().getValue();
			this.getModel().setProperty("/layoutData/I_REVICO", revico);
		},
		getData: function () {
			this.getView().getModel().setProperty("/layoutData/I_FIRST", " ");
			let revinm = this.getView().getModel().getProperty("/layoutData/I_REVINM");
			let revico = this.getView().getModel().getProperty("/layoutData/I_REVICO");
			var self = this;
			$.ajax({
				url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
				type: "post",
				contentType: "application/json",
				data: JSON.stringify({
					importData: {
						I_REVINM: revinm,
						I_REVICO: revico,
						I_USERID: self.getUserId()
					},
					function: "ZB_GET_COMMUNITY_CREATE01",
					dataType: "json",
					success: function (res) {
						let E_MSG = res.exportData.E_MSG;
						let E_RESULT = res.exportData.E_RESULT;
						let T_OLIST = res.exportData.T_OLIST;
						let rfcData = {
							E_MSG: [E_MSG],
							E_RESULT: [E_RESULT],
							T_OLIST: T_OLIST
						};
						self.getView().getModel().setProperty("/rfcData", rfcData)

					},
					error: function (e) {}
				})
			});
			MessageBox.show("게시글이 등록되었습니다.");
			self.getRouter().navTo("community");
			window.location.reload();
		},
		action: function (oEvent) {
			var that = this;
			var actionParameters = JSON.parse(oEvent.getSource().data("wiring").replace(/'/g, "\""));
			var eventType = oEvent.getId();
			var aTargets = actionParameters[eventType].targets || [];
			aTargets.forEach(function (oTarget) {
				var oControl = that.byId(oTarget.id);
				if (oControl) {
					var oParams = {};
					for (var prop in oTarget.parameters) {
						oParams[prop] = oEvent.getParameter(oTarget.parameters[prop]);
					}
					oControl[oTarget.action](oParams);
				}
			});
			var oNavigation = actionParameters[eventType].navigation;
			if (oNavigation) {
				var oParams = {};
				(oNavigation.keys || []).forEach(function (prop) {
					oParams[prop.name] = encodeURIComponent(JSON.stringify({
						value: oEvent.getSource().getBindingContext(oNavigation.model).getProperty(prop.name),
						type: prop.type
					}));
				});
				if (Object.getOwnPropertyNames(oParams).length !== 0) {
					this.getOwnerComponent().getRouter().navTo(oNavigation.routeName, oParams);
				} else {
					this.getOwnerComponent().getRouter().navTo(oNavigation.routeName);
				}
			}
		}
	});
});