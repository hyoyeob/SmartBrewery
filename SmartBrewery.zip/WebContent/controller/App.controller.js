sap.ui.define(['./BaseController', 'sap/ui/core/Fragment',
	'sap/ui/core/mvc/Controller', 'sap/ui/model/json/JSONModel',
	'sap/m/ResponsivePopover', 'sap/m/MessagePopover', 'sap/m/ActionSheet',
	'sap/m/Button', 'sap/m/Link', 'sap/m/Bar',
	'sap/ui/layout/VerticalLayout', 'sap/m/NotificationListItem',
	'sap/m/MessagePopoverItem', 'sap/ui/core/CustomData',
	'sap/m/MessageToast', 'sap/ui/Device', 'sap/ui/core/syncStyleClass',
	'sap/m/library'
], function (BaseController, Fragment, Controller,
	JSONModel, ResponsivePopover, MessagePopover, ActionSheet, Button,
	Link, Bar, VerticalLayout, NotificationListItem, MessagePopoverItem,
	CustomData, MessageToast, Device, syncStyleClass, mobileLibrary) {
	"use strict";

	var PlacementType = mobileLibrary.PlacementType;
	var ButtonType = mobileLibrary.ButtonType;

	return BaseController.extend("SmartBrewer.RegistProject.controller.App", {
		_bExpanded: true,

		onInit: function () {

			console.log('app init')
				// console.log(sap.ushell)
				// var assetService = sap.ushell.Container.getService('AssetService')

			var appData = {
				id: null
			};
			var appModel = new sap.ui.model.json.JSONModel(appData);
			sap.ui.getCore().setModel(appModel, "appModel");
			this.getView().addStyleClass(
				this.getOwnerComponent().getContentDensityClass());
			if (Device.resize.width <= 1024) {
				this.onSideNavButtonPress();
			}
			Device.media.attachHandler(function (oDevice) {
				if ((oDevice.name === "Tablet" && this._bExpanded) || oDevice.name === "Desktop") {
					this.onSideNavButtonPress();

					this._bExpanded = (oDevice.name === "Desktop");
				}
			}.bind(this));
			this.getLoginSet();

			// console.log(localStorage.getItem("LoginCode"));
			// if (localStorage.getItem("LoginCode") === "S") {
			// 	this.getView().byId("container-RegistProject---app--loginButton").setVisible(false);
			// 	this.getView().byId("SignupButton").setVisible(false);
			// 	this.getView().byId("userButton").setText(localStorage.getItem("UserName") + "(" + localStorage.getItem("UserNickName") + ")");
			// 	if (localStorage.getItem("UserType") !== "A") {
			// 		this.getView().byId("adminMark").setVisible(false);
			// 	} else {
			// 		this.getView().byId("adminMark").setVisible(true);
			// 	}
			// } else {
			// 	localStorage.setItem("UserId", "");
			// 	this.getView().byId("adminMark").setVisible(false);
			// 	this.getView().byId("container-RegistProject---app--loginButton").setVisible(true);
			// 	this.getView().byId("SignupButton").setVisible(true);
			// 	this.getView().byId("userButton").setVisible(false);
			// }
		},

		onItemSelect: function (oEvent) {
			var oItem = oEvent.getParameter('item');
			var sKey = oItem.getKey();
			if (sKey === "mypage") {
				if (this.getLoginCode() === "S") {
					this.getRouter().navTo(sKey);
				} else {
					this.LoginCheckDialog();
				}
			} else if (sKey === "thanksto") {
				if (!this._dialog) {
					this._dialog = sap.ui.xmlfragment("SmartBrewer.RegistProject.view.thanksto", this);
					this.getView().addDependent(this._dialog);
				}
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._dialog);
				this._dialog.open();
			} else {
				this.getRouter().navTo(sKey);
			}
		},
		onClose: function () {
			this._dialog.close();
		},

		getLoginSet: function () {
			console.log(localStorage.getItem("LoginCode"));
			var oModel = this.getOwnerComponent().getModel('uiControl');
			if (localStorage.getItem("LoginCode") === "S") {
				if (oModel) {
					if (localStorage.getItem("UserType") !== "A") {
						oModel.setData({
							visibleLoginButton: false,
							visibleUserButton: true,
							visibleAdminflag: false
						});
					} else {
						oModel.setData({
							visibleLoginButton: false,
							visibleUserButton: true,
							visibleAdminflag: true
						});
					}
					sap.ui.getCore().byId("container-RegistProject---app--userButton").setText(localStorage.getItem("UserName") + "(" + localStorage.getItem(
						"UserNickName") + ")");
				}
			} else {
				localStorage.setItem("UserId", "");
				if (oModel) {
					oModel.setData({
						visibleLoginButton: true,
						visibleUserButton: false,
						visibleAdminflag: false
					});
				}
			}
		},

		onUserNamePress: function (oEvent) {
			var self = this;
			var onUserEdit = function (oEvevt) {
				self.getRouter().navTo("userinfomodify");
			};
			var onMypage = function () {
				self.getRouter().navTo("mypage");
			};
			var onSignout = function () {
				self.UserReset();
				self.getLoginSet();
				self.getRouter().navTo("home");
				window.location.reload();
			};
			var oActionSheet = new ActionSheet(this.getView().byId("userMessageActionSheet"), {
				showCancelButton: false,
				buttons: [new Button({
					text: "User edit",
					type: ButtonType.Transparent,
					press: onUserEdit
				}), new Button({
					text: 'Sign out',
					type: ButtonType.Transparent,
					press: onSignout
				}), new Button({
					text: 'My page',
					type: ButtonType.Transparent,
					press: onMypage
				})],
				afterClose: function () {
					// self.getView().byId("userButton").close();
					// oActionSheet.destroy();
				}
			});
			syncStyleClass(this.getView().getController().getOwnerComponent()
				.getContentDensityClass(), this.getView(), oActionSheet);
			oActionSheet.openBy(oEvent.getSource());
		},

		onSideNavButtonPress: function () {
			var oToolPage = this.byId("app");
			var bSideExpanded = oToolPage.getSideExpanded();
			this._setToggleButtonTooltip(bSideExpanded);
			oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
		},
		onLogin: function () {
			this.getRouter().navTo("loginpage");

		},
		onSignUp: function () {
			this.getRouter().navTo("userregist");

		},
		_setToggleButtonTooltip: function (bSideExpanded) {
			var oToggleButton = this.byId('sideNavigationToggleButton');
			if (bSideExpanded) {
				oToggleButton.setTooltip('Large Size Navigation');
			} else {
				oToggleButton.setTooltip('Small Size Navigation');
			}
		},
		/**
		 * 알림같은걸 볼 수 있음
		 */
		onNotificationPress: function (oEvent) {
			var oBundle = this.getModel("i18n").getResourceBundle();
			// close message popover
			var oMessagePopover = this.byId("errorMessagePopover");
			if (oMessagePopover && oMessagePopover.isOpen()) {
				oMessagePopover.destroy();
			}
			var oButton = new Button({
				text: oBundle.getText("notificationButtonText"),
				press: function () {
					MessageToast.show("Show all Notifications was pressed");
				}
			});
			var oNotificationPopover = new ResponsivePopover(this.getView()
				.createId("notificationMessagePopover"), {
					title: oBundle.getText("notificationTitle"),
					contentWidth: "300px",
					endButton: oButton,
					placement: PlacementType.Bottom,
					content: {
						path: 'alerts>/alerts/notifications',
						factory: this._createNotification
					},
					afterClose: function () {
						oNotificationPopover.destroy();
					}
				});
			this.byId("app").addDependent(oNotificationPopover);
			syncStyleClass(this.getView().getController().getOwnerComponent()
				.getContentDensityClass(), this.getView(),
				oNotificationPopover);
			oNotificationPopover.openBy(oEvent.getSource());
		}
	});
});