sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController', 'sap/ui/model/json/JSONModel', 'sap/m/MessageBox',
	"sap/ui/VersionInfo", "sap/ui/core/mvc/XMLView"
], function (
	BaseController, JSONModel, MessageBox, VersionInfo, XMLView) {
	"use strict";

	return BaseController.extend("SmartBrewer.RegistProject.controller.intro", {

		onInit: function () {},

		oncancel: function () {}
	});

});