sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController', 'sap/ui/model/json/JSONModel',
	"sap/ui/VersionInfo", "sap/ui/core/mvc/XMLView", 'sap/m/MessageToast', 'sap/m/MessageBox'
], function (
	BaseController, JSONModel, VersionInfo, XMLView, MessageToast, MessageBox) {
	"use strict";
	var stab = "P";
	var sort = "1";

	var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";

	return BaseController.extend("SmartBrewer.RegistProject.controller.project.ProjectList", {

		onInit: function () {
			var self = this;
			var oModel = new JSONModel();
			let jsonData = {};
			if (this.getLoginCode() === "S") {
				this.getView().byId("joinMenu").setVisible(true);
				this.getView().byId("likeMenu").setVisible(true);
			} else {
				this.getView().byId("joinMenu").setVisible(false);
				this.getView().byId("likeMenu").setVisible(false);
			}

			$.ajax({
				url: rfc_url,
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify({
					importData: {
						I_TAB: stab,
						I_USERID: localStorage.getItem("UserId"),
						I_SORT: sort
					},
					function: "ZB_FD_LIST"
				}),
				dataType: 'json',
				success: function (res) {
					console.log(res);
					let T_TABLE = res.exportData.T_LIST;
					let rfcData = {
						T_TABLE: T_TABLE
					}
					self.getModel().setProperty('/rfcData', rfcData);
				},
				error: function (e) {
					MessageToast.show(e);
				}
			});
			this.setModel(oModel);
			oModel.setData(jsonData);

		},

		onsearch: function (oEvent) {
			var self = this;
			var sskey = oEvent.getSource().getValue();
			$.ajax({
				url: rfc_url,
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify({
					importData: {
						"I_KEY": sskey,
						"I_TAB": stab,
						"I_USERID": localStorage.getItem("UserId"),
						"I_SORT": sort
					},
					function: "ZB_FD_SEARCH"
				}),
				dataType: 'json',
				success: function (res) {
					let T_TABLE = res.exportData.T_LIST;
					console.log(T_TABLE)
					let rfcData = {
						T_TABLE: T_TABLE
					}
					self.getModel().setProperty('/rfcData', rfcData);
				},
				error: function (e) {
					MessageToast.show(e);
				}
			});
			console.log(sskey);
		},

		onOpenRegist: function () {
			var self = this;
			if (self.getLoginCode() === "S") {
				this.getRouter().navTo("registproject");
			} else {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.show(
					'로그인이 필요한 서비스입니다.', {
						title: "로그인",
						actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						initialFocus: "Sign in",
						onClose: function (sAction) {
							if (sAction === "로그인") {
								self.getRouter().navTo("loginpage");
							}
						}
					}
				);
			}
		},

		oninfopage: function (oEvent) {
			var oModel = new JSONModel();
			this.getOwnerComponent().setModel(oModel);
			var self = this;
			var oItem = oEvent.getSource();
			var projid = oItem.getBindingContext().getProperty("PROJID");
			var projectData = {
				PROJID: projid
			};
			console.log(projectData);
			this.getOwnerComponent().getModel().setProperty('/projectData', projectData);

			var key = "projectdetail",
				oOwner = this.getOwnerComponent();
			oOwner.getRouter().navTo(key, {
				PROJID: projid
			});
		},
		fdcancel: function (oEvent) {
			var self = this;
			var oItem = oEvent.getSource();
			var projid = oItem.getBindingContext().getProperty("PROJID");
			var userid = localStorage.getItem("UserId");
			var per = oItem.getBindingContext().getProperty("ORDPER");

			console.log(projid, per);
			if (per == "100") {
				sap.m.MessageBox.show(
					'이미 종료된 펀딩입니다.', {
						title: "취소실패",
						actions: [sap.m.MessageBox.Action.CLOSE],
						onClose: function (sAction) {

						}
					}
				);

			} else {
				$.ajax({
					url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_USERID: userid,
							I_PROJID: projid
						},
						function: "ZB_JOIN_CANCEL"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						var FundingJoin = {
							E_MSG: res.exportData.E_MSG,
							E_SUBRC: res.exportData.E_SUBRC
						};
						var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;
						//정상 주문 체크 논리 필요
						sap.m.MessageBox.show(
							'펀딩 참여를 취소했습니다.', {
								title: "취소완료",
								actions: [sap.m.MessageBox.Action.CLOSE],
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (sAction) {
									// self.getRouter().navTo("projectlist");
									// window.location.reload();
								}
							}
						);
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});
			}

		},
		handleIconTabBarSelect: function (oEvent) {
			this.onOpenDialog();
			var sKey = oEvent.getParameter("key");
			var self = this;
			if (sKey == "pfund") {
				stab = "P"
			} else if (sKey == "jfund") {
				stab = "J"
			} else if (sKey == "efund") {
				stab = "E"
			} else if (sKey == "ffund") {
				stab = "L"
			} else if (sKey == "regist") {
				if (self.getLoginCode() === "S") {
					this.getRouter().navTo("registproject");
					window.location.reload();
					return;
				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.show(
						'로그인이 필요한 서비스입니다.', {
							title: "로그인",
							actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							initialFocus: "Sign in",
							onClose: function (sAction) {
								if (sAction === "로그인") {
									self.getRouter().navTo("loginpage");
								}
							}
						}
					);
				}
			}

			$.ajax({
				url: rfc_url,
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify({
					importData: {
						I_TAB: stab,
						I_USERID: localStorage.getItem("UserId"),
						I_SORT: sort
					},
					function: "ZB_FD_LIST"
				}),
				dataType: 'json',
				success: function (res) {
					console.log(res);
					let T_TABLE = res.exportData.T_LIST;
					console.log(T_TABLE)
					let rfcData = {
						T_TABLE: T_TABLE
					}
					self.getModel().setProperty('/rfcData', rfcData);
				},
				error: function (e) {
					MessageToast.show(e);
				}
			});

		},
		handleSelectChange: function (oEvent) {
			var sKey = oEvent.getSource().getSelectedItem().getKey();
			// console.log(sKey)
			var self = this;

			if (sKey == "REDIDY") {
				sort = "1"
			} else if (sKey == "ORDPER") {
				sort = "2"
			} else if (sKey == "VIEWCT") {
				sort = "3"
			} else if (sKey == "COMMENT") {
				sort = "4"
			} else if (sKey == "FAVORITE") {
				sort = "5"
			} else if (sKey == "JOINCT") {
				sort = "6"
			}
			// console.log(sort);

			$.ajax({
				url: rfc_url,
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify({
					importData: {
						I_TAB: stab,
						I_USERID: localStorage.getItem("UserId"),
						I_SORT: sort
					},
					function: "ZB_FD_LIST"
				}),
				dataType: 'json',
				success: function (res) {
					console.log(res);
					let T_TABLE = res.exportData.T_LIST;
					let rfcData = {
						T_TABLE: T_TABLE
					}
					self.getModel().setProperty('/rfcData', rfcData);
				},
				error: function (e) {
					MessageToast.show(e);
				}
			});

		}

	});
});