sap.ui.define(
	['SmartBrewer/RegistProject/controller/BaseController', 'sap/ui/model/json/JSONModel',
		"sap/ui/VersionInfo", "sap/ui/core/mvc/XMLView",
		'jquery.sap.global', 'sap/ui/core/Fragment',
		'sap/ui/core/mvc/Controller', 'sap/ui/model/Filter', 'sap/m/MessageToast', 'sap/m/MessageBox',
		'sap/ui/model/FilterOperator'
	],
	function (BaseController, JSONModel, VersionInfo, XMLView,
		jQuery, Fragment, Controller, Filter, MessageToast, MessageBox, FilterOperator) {
		"use strict";
		var err_flag = false;
		var dia_flag = false;
		var test;
		var projid = "";
		var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";
		return BaseController.extend("SmartBrewer.RegistProject.controller.project.RegistProject", {

			onInit: function () {
				var self = this;
				if (self.getLoginCode() !== "S") {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.show(
						'로그인이 필요한 서비스입니다.', {
							title: "로그인",
							actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							initialFocus: "Sign in",
							onClose: function (sAction) {
								if (sAction === "로그인") {
									self.getRouter().navTo("loginpage");
									window.location.reload();
									return;
								} else {
									self.getRouter().navTo("projectlist");
									window.location.reload();
									return;
								}
							}
						}
					);
				}

				var date = new Date();
				date.setMonth(date.getMonth() + 1);
				var oModel = new JSONModel();

				var jsonData = {
					rfcData: {
						T_REGFORM: [],
						ADD_TABLE: []
					},
					otherData: {
						newNum: 0,
						dateValue: date
					},
					masterData: {
						ADDLST: [],
						NURLST: []
					},
					layoutData: {}
				};
				this.setModel(oModel);
				oModel.setData(jsonData);

				$.ajax({
					url: rfc_url,
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {},
						function: "ZB_GET_ADDI_LIST"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						var ADDLST = res.exportData.T_ZBSDT0030;
						$.each(ADDLST, function (index, oData) {
							oData.CODE = index + '';
						});
						var masterData = {
							ADDLST: ADDLST,
							IMG: [{
								key: "01",
								title: "1번 병",
								image: "model/src/bottle/bottle_1.png"
							}, {
								key: "02",
								title: "2번 병",
								image: "model/src/bottle/bottle_2.png"
							}, {
								key: "03",
								title: "3번 병",
								image: "model/src/bottle/bottle_3.png"
							}, {
								key: "04",
								title: "4번 병",
								image: "model/src/bottle/bottle_4.png"
							}],
							NURLST: [{
								GROUP: "NUR",
								NURUCD: "01",
								VALUE: "백미"
							}, {
								GROUP: "NUR",
								NURUCD: "02",
								VALUE: "현미"
							}, {
								GROUP: "NUR",
								NURUCD: "03",
								VALUE: "보리"
							}],
							YSTLST: [{
								GROUP: "YST",
								YEASTC: "01",
								VALUE: "이스트"
							}],
							SUGLST: [{
								GROUP: "SUG",
								SUGACD: "01",
								VALUE: "올리고당"
							}, {
								GROUP: "SUG",
								SUGACD: "02",
								VALUE: "물엿"
							}, {
								GROUP: "SUG",
								SUGACD: "03",
								VALUE: "조청"
							}],
							COLLST: [{
								GROUP: "COL",
								COLORC: "01",
								VALUE: "빨간색"
							}, {
								GROUP: "COL",
								COLORC: "02",
								VALUE: "노란색"
							}, {
								GROUP: "COL",
								COLORC: "03",
								VALUE: "살구색"
							}, {
								GROUP: "COL",
								COLORC: "04",
								VALUE: "보라색"
							}, {
								GROUP: "COL",
								COLORC: "05",
								VALUE: "갈색"
							}]
						};
						var otherData = {
							HTMLSTR: "<div id=\"previewContent\"></div>"
						};
						self.getModel().setProperty('/otherData', otherData);
						self.getModel().setProperty('/masterData', masterData);
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});
				if (this.getUserType() === "A") {
					this.getView().byId("fundst").setVisible(true);
					this.getView().byId("fundlb").setVisible(true);
				} else {
					this.getView().byId("fundst").setVisible(false);
					this.getView().byId("fundlb").setVisible(false);
				}

				setTimeout(function () {
					self.getUserInfo();
				}, 1000);
			},
			getUserInfo: function () {
				var self = this;
				$.ajax({
					url: rfc_url,
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_USERID: self.getUserId()
						},
						function: "ZB_GET_USER_INQUIRY"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						var UserData = {
							userInfo: [{
								E_USERID: res.exportData.E_USERID,
								E_USERNM: res.exportData.E_USERNM,
								E_USERYR: res.exportData.E_USERYR,
								E_USERTL: res.exportData.E_USERTL,
								E_USERMA: res.exportData.E_USERMA,
								E_USERNI: res.exportData.E_USERNI
							}]
						};
						self.getModel().setProperty('/UserData', UserData);

						self.byId("UserNameInput").setValue(res.exportData.E_USERNM);
						self.byId("phoneNumberInput").setValue(res.exportData.E_USERTL);
						self.byId("emailInput").setValue(res.exportData.E_USERMA);
						console.log(res.exportData);
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});
			},

			Imgupload: function (oEvent) {
				var key = oEvent.getSource().getName();
				let self = this;
				let localFile = oEvent.getParameter('files')[0];
				let reader = new FileReader();
				var oModel = new JSONModel();
				console.log(localFile, key);
				this.getView().getModel().setProperty('/layoutData/file', localFile);
				console.log(this.getView().getModel());
				reader.readAsDataURL(localFile);
				reader.onload = function () {
					console.log(reader);
					self.getView().getModel().setProperty('/layoutData/imageUrl', reader.result);
					self.img(key);
				};
			},

			img: function (key) {
				var self = this;
				var form = new FormData();
				var file = this.getView().getModel().getProperty('/layoutData/file');
				console.log(file);
				form.append("image", file);
				$.ajax({
					url: 'https://api.imgur.com/3/image/',
					method: "POST",
					crossDomain: true,
					headers: {
						Authorization: "Client-ID 22f626626686a62",
						Accept: 'application/json'
					},
					mimeType: 'multipart/form-data',
					contentType: false,
					processData: false,
					data: form,
					success: function (res) {
						console.log(JSON.parse(res).data.link);
						if (key === "03") {
							self.getView().byId('LabelImage').setValue(JSON.parse(res).data.link);
							self.getView().byId('preview').setSrc(JSON.parse(res).data.link);
						} else {
							$.ajax({
								url: rfc_url,
								type: 'POST',
								contentType: 'application/json',
								data: JSON.stringify({
									importData: {
										I_PROJID: self.getModel().getProperty('/rfcData/PROJID'),
										I_SEQ: key,
										I_IMGLNK: JSON.parse(res).data.link
									},
									function: "ZB_SET_PROJECT_IMAGE"
								}),
								dataType: 'json',
								success: function (res) {
									console.log(res);
									var E_PROJID = res.exportData.E_PROJID;
									self.getModel().setProperty('/rfcData/PROJID', E_PROJID);
									console.log(self.getModel());
								},
								error: function (e) {
									MessageToast.show(e);
								}
							});
						}
					}
				})
			},

			urlRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var regExp = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
				var sState = regExp.test(newValue) ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}

			},
			phoneRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var regExp = /(01[016789])-([1-9]{1}[0-9]{2,3})-([0-9]{4})$/;
				var sState = regExp.test(newValue) ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},

			emailRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var regExp = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;
				var sState = regExp.test(newValue) ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},
			TextLengthCheck: function (oEvent) {
				var newValue = oEvent.getParameter("value").length;
				var iMaxLength = oEvent.getSource().getMaxLength();
				var sState = newValue > iMaxLength ? "Warning" : "None";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},
			selectCount: function (oEvent) {
				var self = this;
				let changeKey = oEvent.getSource().getSelectedKey();
				var img = self.getModel().getProperty('/masterData/IMG').filter(function (status) {
					return status.key == changeKey
				});

				this.getView().byId("BottleImagePreview").setSrc(img[0]["image"]);

				// var test2 = test[key]
			},

			onSavefrg: function (oEvent) {
				var msg = '이미지를 불러왔습니다.';
				var self = this;
				MessageToast.show(msg);

				var sImageSrc = this.getView().byId('preview').getSrc();
				$.ajax({
					url: rfc_url,
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_PROJID: self.getModel().getProperty('/rfcData/PROJID'),
							I_SEQ: "03",
							I_IMGLNK: sImageSrc
						},
						function: "ZB_SET_PROJECT_IMAGE"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						var E_PROJID = res.exportData.E_PROJID;
						self.getModel().setProperty('/rfcData/PROJID', E_PROJID);
						console.log(self.getModel());
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});

				this.getView().byId('LabelImage').setValue(sImageSrc);

				this.byId("ListDialog").close();
				this.byId("ListDialog").destroy();

			},

			onExit: function () {
				console.log(this);
				this.byId("ListDialog").close();
				this.byId("ListDialog").destroy();

			},

			previewBtn: function (oEvent) {
				this.byId('preview').setSrc(test);
			},

			labelPress: function (oEvent) {
				this.byId('preview').setSrc(oEvent.getSource().getSrc());
				// this.byId('preview').setSrc(oEvent.getSource().getTileContent().getImageContent().getSrc());
			},

			upload: function (oEvent) {
				let localFile = oEvent.getParameter('files')[0]
				console.log(localFile)
				let reader = new FileReader();

				let self = this;
				reader.readAsDataURL(localFile);
				reader.onload = function () {
					console.log(reader.result)
					test = reader.result
				}
			},

			onPress: function (oEvent) {
				var oView = this.getView();
				var self = this;

				if (!this.byId("ListDialog")) {
					Fragment.load({
						id: oView.getId(),
						name: "SmartBrewer.RegistProject.view.order.menu.Image",
						controller: self
					}).then(function (oDialog2) {
						oView.addDependent(oDialog2);
						oDialog2.open();
					})
				} else {
					this.byId('ListDialog').open();
				}
			},

			blobToBase64: function (blob) {
				var oDeferred = jQuery.Deferred(),
					reader = new FileReader();
				reader.onload = function () {
					var sBinaryData = reader.result;
					setTimeout(function () {
						oDeferred.resolve(sBinaryData);
					}, 10);
				};
				reader.readAsDataURL(blob);
				return oDeferred;
			},

			onDelete: function (oEvent) {
				var table = this.getModel().getProperty('/rfcData/ADD_TABLE');
				var addTable = this.getView().byId('AdditiveInputTable');
				var selectedNum = addTable.getSelectedIndices();

				$.each(selectedNum.reverse(), function (index, indexValue) {
					table.splice(indexValue, 1);
				});
				this.getModel().setProperty('/rfcData/ADD_TABLE', table);
				addTable.clearSelection();
			},

			onPreview: function (oEvent) {
				var newValue = this.byId('ProjectContentsInput').getValue();
				var otherData = {
					HTMLSTR: newValue
				};
				this.getModel().setProperty('/otherData', otherData);
				console.log(this.getModel().getProperty('/otherData'));
				jQuery("#previewContent").empty().append(newValue);
			},

			onAfterRendering: function () {
				// if (!this.byId('projectContents').getContent()) {
				//    this.byId('projectContents').setContent('<div id=\"previewContent\"></div>');
				// }
				var otherData = {
					HTMLSTR: "<div id=\"previewContent\"></div>"
				};
				this.getModel().setProperty('/otherData', otherData);
			},

			onAdd: function (evt) {
				var table = this.getModel().getProperty('/rfcData/ADD_TABLE');
				table.push({});
				this.callTable(this);
			},
			onSave: function (I_BTNTYP) {
				var self = this;
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				if (err_flag === true) {
					MessageBox.confirm(
						"필드에 공백없이 정확한 값을 입력해주세요.", {
							icon: MessageBox.Icon.WARNING,
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							actions: [MessageBox.Action.OK]
						});
					return;
				} else if (
					self.getView().byId("ProjectNameInput").getValue() === "" || self.getView().byId("MaximumOrderQuantityInput").getValue() === "" ||
					self.getView().byId("ProductNameInput").getValue() === "" || self.getView().byId("ProductPriceInput").getValue() === "" || self.getView()
					.byId("ProductExplainInput").getValue() === "" || self.getView().byId("ProjectEndDateInput").getValue() === "" || self.getView().byId(
						"TargetOrderQuantityInput").getValue() === ""
				) {
					MessageBox.confirm(
						"필드에 공백없이 정확한 값을 입력해주세요.", {
							icon: MessageBox.Icon.WARNING,
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							actions: [MessageBox.Action.OK]
						});
					return;
				}
				var self = this;
				//선언부
				if (self.byId("SterilizationInput").getSelectedIndex() === 0) {
					var STERTF = 'X';
				}
				if (self.byId("RequiredCertificateInput").getSelectedIndex() === 0) {
					var CERTFG = 'X';
				}
				if (self.byId("MandatoryConfirmationInput").getSelectedIndex() === 0) {
					var CONFFG = 'X';
				}
				if (self.byId("fundst").getSelectedIndex() === -1) {
					var PROJTY = 'FD';
				} else if (self.byId("fundst").getSelectedIndex() === 0) {
					var PROJTY = 'LI';
				} else {
					var PROJTY = 'NM';
				}

				//호출부
				var I_TRFORM = {
					PROJID: self.byId("ProjectNumberInput").getValue(),
					USERMA: self.byId("emailInput").getValue(),
					USERTL: self.byId("phoneNumberInput").getValue(),
					PROJNM: self.byId("ProjectNameInput").getValue(),
					OBJEOR: self.byId("TargetOrderQuantityInput").getValue(),
					CERTFG: CERTFG,
					CONFFG: CONFFG,
					PROJEN: self.byId("ProjectEndDateInput").getValue(),
					PRESPR: self.byId("ProductPriceInput").getValue(),
					PRESNM: self.byId("ProductNameInput").getValue(),
					MAXORD: self.byId("MaximumOrderQuantityInput").getValue(),
					BOTTTY: self.byId("BottleTypeInput").getSelectedKey(),
					PROJSM: self.byId("ProductExplainInput").getValue(),
					USERNM: self.byId("UserNameInput").getValue(),
					BLOGLK: self.byId("BlogInput").getValue(),
					WEBPLK: self.byId("WebpageInput").getValue(),
					STERTF: STERTF,
					FSTTEM: self.byId("FstTempInput").getValue(),
					SCDTEM: self.byId("ScdTempInput").getValue(),
					FSTMIX: self.byId("FstMixInput").getValue(),
					SCDMIX: self.byId("ScdMixInput").getValue(),
					RICEMO: self.byId("RiceAmountInput").getValue(),
					NURUCD: self.byId("NurukTypeInput").getSelectedKey(),
					NURUMO: self.byId("NurukAmountInput").getValue(),
					SUGACD: self.byId("SugarTypeInput").getSelectedKey(),
					SUGAMO: self.byId("SugarAmountInput").getValue(),
					WATEMO: self.byId("WaterAmountInput").getValue(),
					ALCHPE: self.byId("AlcAmountInput").getValue(),
					COLORC: self.byId("colorTypeInput").getSelectedKey(),
					YEASTC: self.byId("YeastTypeInput").getSelectedKey(),
					YEASTM: self.byId("YeastAmountInput").getValue()
						// CURRCY: "KRW"
				};

				self.callTable(self);
				var T_ZBSDT0050 = self.getModel().getProperty('/rfcData/ADD_TABLE');
				var I_STRING = self.byId("ProjectContentsInput").getValue();
				console.log(T_ZBSDT0050); //rfc에 프로젝트 아이디 없이도 들어가도록 로직 작성하기 (10-26)
				console.log(I_TRFORM);

				//통신부
				console.log(self.getUserId());
				$.ajax({
					url: rfc_url,
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_TRFORM: I_TRFORM,
							I_BTNTYP: I_BTNTYP,
							I_USERID: self.getUserId(),
							I_PROJTY: PROJTY,
							I_STRING: I_STRING,
							T_ZBSDT0050: T_ZBSDT0050
						},
						function: "ZB_GET_FUNDING_REGIST_FORM"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						var PROJID = res.exportData.E_PROJID;
						projid = res.exportData.E_PROJID;
						self.getModel().setProperty('/rfcData/PROJID', PROJID);
						MessageToast.show("임시 저장되었습니다.");
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});
			},

			callTable: function (self) {
				var table = self.getModel().getProperty('/rfcData/ADD_TABLE');
				var addTable = self.getView().byId('AdditiveInputTable');
				var ADD_TABLE = [];

				for (var i = 0; i < table.length; i++) {
					ADD_TABLE.push({
						ADDICD: addTable.getRows()[i].getCells()[0].getSelectedKey(),
						PROJID: self.byId("ProjectNumberInput").getValue(),
						ADDIMO: addTable.getRows()[i].getCells()[1].getValue(),
						USERID: self.getUserId()
					});
				}
				self.getModel().setProperty('/rfcData/ADD_TABLE', ADD_TABLE);
			},

			onRequest: function () {
				var self = this;
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				if (err_flag === true) {
					MessageBox.confirm(
						"필드에 공백없이 정확한 값을 입력해주세요.", {
							icon: MessageBox.Icon.WARNING,
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							actions: [MessageBox.Action.OK]
						});
					return;
				} else if (
					self.getView().byId("ProjectNameInput").getValue() === "" || self.getView().byId("MaximumOrderQuantityInput").getValue() === "" ||
					self.getView().byId("ProductNameInput").getValue() === "" || self.getView().byId("ProductPriceInput").getValue() === "" || self.getView()
					.byId("ProductExplainInput").getValue() === "" || self.getView().byId("ProjectEndDateInput").getValue() === "" || self.getView().byId(
						"TargetOrderQuantityInput").getValue() === ""
				) {
					MessageBox.confirm(
						"필드에 공백없이 정확한 값을 입력해주세요.", {
							icon: MessageBox.Icon.WARNING,
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							actions: [MessageBox.Action.OK]
						});
				} else {
					MessageBox.confirm(
						"최종 제출 후엔 수정하실 수 없습니다. 제출하시겠습니까?", {
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							onClose: function (sAction) {
								if (sAction === "OK") {
									self.onSave('R');
									self.getRouter().navTo("projectlist");
								}
							}
						}
					);
				}

			},

			onOpenDialog: function (oEvent) {
				if (dia_flag === false) {
					dia_flag = true;
					if (!this._oDialog) {
						this._oDialog = sap.ui.xmlfragment("SmartBrewer.RegistProject.view.project.reg_fragment.Code", this);
					}
					this.getView().addDependent(this._oDialog);
					this._oDialog.open();
					this._oDialog.close();
					this.PreviewDialogPress();
					// var _timeout = jQuery.sap.delayedCall(500, this, function () {
					//    this._oDialog.close();
					//    this.PreviewDialogPress();
					// }); 
				} else {
					this.PreviewDialogPress();
				}
			},

			PreviewDialogPress: function (oEvent) {
				var newValue = this.byId('ProjectContentsInput').getValue();
				var otherData = {
					HTMLSTR: newValue
				};

				if (!this._oDialog) {
					this._oDialog = sap.ui.xmlfragment("SmartBrewer.RegistProject.view.project.reg_fragment.Code", this);
				}
				this._oDialog.setContentHeight("75%");
				this._oDialog.setContentWidth("75%");

				this.getModel().setProperty('/otherData', otherData);
				this.getView().addDependent(this._oDialog);
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
				jQuery("#previewContent").empty().append(newValue);
				this.onAfterRendering();
				this._oDialog.open();
			},

			codeBeauty: function (oEvent) {
				this.getView().byId("ProjectContentsInput").prettyPrint();
			},

			handleClose: function (oEvent) {
				this._oDialog.close();
			}
		});
	});