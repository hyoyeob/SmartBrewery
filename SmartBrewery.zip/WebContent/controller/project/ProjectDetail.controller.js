sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController', "sap/ui/model/json/JSONModel",
		"sap/m/Dialog", "sap/m/Button", "sap/m/Text", "sap/m/Input", "sap/m/Label", "sap/m/TextArea", "sap/ui/model/Filter", "jquery.sap.global",
		"sap/ui/core/mvc/Controller", "sap/m/MessagePopover", "sap/m/MessagePopoverItem", "sap/m/MessageBox"
	],
	function (BaseController, JSONModel, Dialog, Button, Text, Input, Label, TextArea, Filter, MessagePopover, MessagePopoverItem, jquery,
		MessageBox) {
		"use strict";
		var renderFlag = false;
		var nextpagety = "TYNM";
		return BaseController.extend("SmartBrewer.RegistProject.controller.project.ProjectDetail", {
			onInit: function () {
				var oRouter = this.getRouter();
				oRouter.getRoute("projectdetail").attachMatched(this._onRouteMatched, this);
			},

			_onRouteMatched: function (oEvent) {
				var oArgs, oView;
				var self = this;
				let jsonData = {};
				var oModel = new JSONModel();
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				this.onOpenDialog();

				oArgs = oEvent.getParameter("arguments");
				oView = this.getView();

				this.getView().setModel(oModel);
				this.getView().getModel().setData(jsonData);
				var otherData = {
					HTMLSTR: "<div id=\"previewContent\"></div>"
				};
				this.getModel().setProperty('/otherData', otherData);

				$.ajax({
					url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_PROJID: oArgs.PROJID,
							I_USERID: self.getUserId()

						},
						function: "ZB_GET_FUNDING_DETAIL"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res)
						let rfcData = {
							E_PRESPR: res.exportData.E_PRESPR, //상품 금액
							E_PROJNM: res.exportData.E_PROJNM, //펀딩제목
							E_RIMGLI: res.exportData.E_RIMGLI, //대표이미지 경로X
							E_PROJSM: res.exportData.E_PROJSM, //프로젝트 요약
							E_PROJLI: res.exportData.E_PROJLI, //소개 이미지 경로
							E_PROJCO: res.exportData.E_PROJCO, //프로젝트 내용
							E_OBJEOR: res.exportData.E_OBJEOR, //목표 주문량
							E_ORDEMO: res.exportData.E_ORDEMO, //총 주문량
							E_ORDEPR: res.exportData.E_ORDEPR, //주문가격
							E_FUNDST: res.exportData.E_FUNDST, //상태
							E_PROJEN: res.exportData.E_PROJEN, //종료일
							E_REMDAY: res.exportData.E_REMDAY, //남은기간
							E_ORDPER: res.exportData.E_ORDPER, //진행률
							E_PRESNM: res.exportData.E_PRESNM, //상품명
							E_REMORD: res.exportData.E_REMORD, //남은량
							E_ACCEPT: res.exportData.E_ACCEPT,
							E_CODE: res.exportData.E_CODE,
							E_MSG: res.exportData.E_MSG,
							E_BLOGLK: res.exportData.E_BLOGLK,
							E_WEBPLK: res.exportData.E_WEBPLK,
							E_DELFLG: res.exportData.E_DELFLG,
							E_ALCHPE: res.exportData.E_ALCHPE,
							E_IMG01: res.exportData.E_IMG01,
							E_IMG02: res.exportData.E_IMG02
						}
						var infoTable = res.exportData.T_ZGET_DETAIL;

						let E_DELFLG = res.exportData.E_DELFLG;
						console.log(infoTable);
						if (E_DELFLG === "X") {
							self.getView().byId("oh1").setBackgroundColor("Accent10");
						} else {
							self.getView().byId("oh1").setBackgroundColor("Accent1");
						}
						if (res.exportData.E_PROJTY === "FD") {
							self.getView().byId("progressBox").setVisible(true);
							self.getView().byId("ordmoBox").setVisible(true);
							self.getView().byId("ordperBox").setVisible(true);
							self.getView().byId("remdayBox").setVisible(true);
							self.getView().byId("slidetile").setVisible(false);
							nextpagety = "FD";
						} else {
							self.getView().byId("progressBox").setVisible(false);
							self.getView().byId("ordmoBox").setVisible(false);
							self.getView().byId("ordperBox").setVisible(false);
							self.getView().byId("remdayBox").setVisible(false);
							self.getView().byId("slidetile").setVisible(true);
							nextpagety = "ELSE";
						}
						console.log(res.exportData.E_ORDPER, res.exportData.E_FUNDST);
						if (res.exportData.E_ORDPER === "100" || res.exportData.E_FUNDST === "B" || res.exportData.E_FUNDST === "C") {
							self.getView().byId("orderButton").setEnabled(false);
						} else {
							self.getView().byId("orderButton").setEnabled(true);

						}

						self.getView().getModel().setProperty('/rfcData', rfcData);
						self.getView().getModel().setProperty('/infoTable', infoTable);
						console.log('hi')
						console.log(self.getView().getModel().getProperty('/'))
						if (renderFlag === false) {
							renderFlag = true;
						} else {
							self.onAfterRendering();
						}

						sap.ui.getCore().setModel(oModel);
						sap.ui.getCore().getModel().setProperty('/projid', oArgs.PROJID);
					},
					error: function (e) {
						console.log(e);
					}
				})

				$.ajax({
					url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_PROJID: oArgs.PROJID
						},
						function: "ZB_GET_FUNDING_ALLCOMMENT01"
					}),
					dataType: 'json',
					success: function (res) {
						var commandList = res.exportData.EXPORT_ALLCOMMENT;
						self.getView().getModel().setProperty('/commData', commandList);
						var EXPORT_ALLCOMMENT = self.getModel().getProperty('/commData');

					},
					error: function (e) {
						MessageToast.show(e);
					}
				});
			},

			pressOnTileOne: function (evt) {
				sap.m.URLHelper.redirect("index.html#/ProjectDetail/102240", true);
			},
			pressOnTileTwo: function (evt) {
				sap.m.URLHelper.redirect("index.html#/ProjectDetail/102230", true);
			},
			pressOnTileThree: function (evt) {
				sap.m.URLHelper.redirect("index.html#/ProjectDetail/102280", true);
			},

			linkPress: function (evt) {
				var bloglk = this.getView().getModel().getProperty("/rfcData/E_BLOGLK");
				console.log(bloglk)
				sap.m.URLHelper.redirect("https://" + bloglk, true);
			},
			linkPress: function (evt) {
				var bloglk = this.getView().getModel().getProperty("/rfcData/E_BLOGLK");
				console.log(bloglk)
				sap.m.URLHelper.redirect("https://" + bloglk, true);
			},
			onPress: function (oEvent) {
				var oModel = new JSONModel();
				this.getOwnerComponent().setModel(oModel);
				var self = this;
				var oItem = oEvent.getSource();
				var projid = location.hash.substr(location.hash.lastIndexOf("/") + 1);
				var projectData = {
					PROJID: projid
				};
				///
				$.ajax({
					url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							"I_PROJID": projid
						},
						function: "ZB_JOIN_PAGE"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res)
						var PageData = {
							E_PRESNM: res.exportData.E_PRESNM,
							E_PRESPR: res.exportData.E_PRESPR,
							E_PROJNM: res.exportData.E_PROJNM,
							E_ORDPER: res.exportData.E_ORDPER,
							E_SUBRC: res.exportData.E_SUBRC,
							E_OBJEOR: res.exportData.E_OBJEOR,
							E_ORDEMO: res.exportData.E_ORDEMO,
							E_REMDAY: res.exportData.E_REMDAY,
							E_MSG: res.exportData.E_MSG,
							E_PROJEN: res.exportData.E_PROJEN,
							E_MAXORD: res.exportData.E_MAXORD,
							E_USERID: res.exportData.E_USERID,
							E_IMG02: res.exportData.E_IMG02,
						};
						self.getOwnerComponent().getModel().setProperty('/PageData', PageData);
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});

				if (nextpagety == "FD") {
					var key = "fundingjoin",
						oOwner = this.getOwnerComponent();
					oOwner.getRouter().navTo(key, {
						PROJID: projid
					});
				} else {
					var key = "recipeorder",
						oOwner = this.getOwnerComponent();
					oOwner.getRouter().navTo(key, {
						PROJID: projid
					});
				}

				console.log(self.getOwnerComponent().getModel());
				// this.getOwnerComponent().getModel().setProperty('/projectData', projectData);

			},

			onFavorite: function () {
				var self = this;
				if (this.getLoginCode() === "S") {
					var projid = location.hash.substr(location.hash.lastIndexOf("/") + 1);
					$.ajax({
						url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_PROJID: projid,
								I_USERID: self.getUserId(),
								I_ORDEID: '000000',
								I_LOCTYP: 'X' // 펀딩 x 주문 o
							},
							function: "ZB_GET_FUNDING_LIKE"
						}),
						dataType: 'json',
						success: function (res) {
							console.log(res)
							let E_DELFLG = res.exportData.E_DELFLG
							if (E_DELFLG === "X") {
								self.getView().byId("oh1").setBackgroundColor("Accent10");
							} else {
								self.getView().byId("oh1").setBackgroundColor("Accent1");
							}
							let otherData = {
								E_DELFLG: E_DELFLG
							}
							self.getView().getModel().setProperty('/otherData', otherData);
						},
						error: function (e) {
							console.log(e);
						}
					})
				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.show(
						'로그인이 필요한 서비스입니다.', {
							title: "로그인",
							actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							initialFocus: "Sign in",
							onClose: function (sAction) {
								if (sAction === "로그인") {
									self.getRouter().navTo("loginpage");
								}
							}
						}
					);
				}
			},
			onAfterRendering: function () {
				var self = this;
				var projid = location.hash.substr(location.hash.lastIndexOf("/") + 1);
				$.ajax({
					url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_PROJID: projid
						},
						function: "ZB_SET_PROJECT_CONTENTS"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res)
						let E_PROJCO = res.exportData.E_PROJCO
						let E_CODE = res.exportData.E_CODE
						let otherData = {
							HTMLSTR: E_PROJCO,
							E_CODE: E_CODE
						}
						jQuery("#previewContent").empty().append(E_PROJCO);
						self.getView().getModel().setProperty('/otherData', otherData);
					},
					error: function (e) {
						console.log(e);
					}
				})
			},
			//공유하기
			CopyUrlToClipboard: function () {
				var obShareUrl = window.document.location.href
				var t = document.createElement("textarea");
				document.body.appendChild(t);
				t.value = obShareUrl;
				t.select();
				var stat = document.execCommand('copy');
				document.body.removeChild(t);
				if (stat) {
					alert("URL이 클립보드에 복사되었습니다");
				} else {
					alert("복사가안되네요");
				}
			},

			onPost: function () {
				var self = this;
				if (this.getLoginCode() === "S") {
					var projid = location.hash.substr(location.hash.lastIndexOf("/") + 1);
					var COMMCO = this.getView().byId("getComment").getValue();
					$.ajax({
						url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_PROJID: projid,
								I_USERID: self.getUserId(),
								I_COMMCO: COMMCO
							},
							function: "ZB_GET_FUNDING_COMMENT01"
						}),
						dataType: 'json',
						success: function (res) {
							var commandList = res.exportData.EXPORT_COMMENT;
							self.getView().getModel().setProperty('/commData', commandList);
							var commData = self.getView().getModel().getProperty('/commData');
							console.log(commData)
						},
						error: function (e) {
							MessageToast.show(e);
						}
					});
				} else {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.show(
						'로그인이 필요한 서비스입니다.', {
							title: "로그인",
							actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							initialFocus: "Sign in",
							onClose: function (sAction) {
								if (sAction === "로그인") {
									self.getRouter().navTo("loginpage");
								}
							}
						}
					);
				}
			},

			onEmail: function () {
				window.location.replace("mailto:hyoyeob@naver.com");
			}

		});
	});