sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController',
	'sap/ui/model/json/JSONModel',
	"sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView"
], function (
	BaseController, JSONModel, VersionInfo, XMLView, jQuery, Fragment, Controller, Filter, MessageToast, MessageBox) {
	"use strict";

	var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";

	return BaseController.extend("SmartBrewer.RegistProject.controller.mypage.MyPage2", {
		onInit: function () {
			var self = this;
			if (this.getLoginCode() !== "S") {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.show(
					'로그인이 필요한 서비스입니다.', {
						title: "로그인",
						actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						initialFocus: "Sign in",
						onClose: function (sAction) {
							if (sAction === "로그인") {
								self.getRouter().navTo("loginpage");
							}
						}
					}
				);
			} else {
				var oModel = new JSONModel();
				this.getView().setModel(oModel);
				var jsonData = {
					imgData: [{
						PROJLI: "index.html#/ProjectDetail/102240"
					}, {
						PROJLI: "index.html#/ProjectDetail/102230"
					}, {
						PROJLI: "index.html#/ProjectDetail/102470"
					}, {
						PROJLI: "index.html#/ProjectDetail/102280"
					}, {
						PROJLI: "index.html#/ProjectDetail/102300"
					}]
				};

				this.getModel().setData(jsonData);

				$.ajax({
					url: rfc_url,
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {},
						function: "ZB_GET_FUNDIG_MYPAGE_PICTURE"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						var T_DATA = res.exportData.T_ZBFDT0010;
						self.getModel().setProperty('/T_DATA', T_DATA);

					},
					error: function (e) {
						MessageToast.show(e);
					},
				});

				var oViewArea = this.getView().byId('viewArea');
				oViewArea.destroyContent();

				oViewArea.addContent(
					sap.ui.xmlview({
						viewName: 'SmartBrewer.RegistProject.view.mypage.Participatefunding'
					})
				);

			}

		},

		onItemSelect: function (oEvent) {
			var key = oEvent.getSource().data('itemKey'),
				sViewId = '';
			var self = this;
			if (this.getLoginCode() !== "S") {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.show(
					'로그인이 필요한 서비스입니다.', {
						title: "로그인",
						actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						initialFocus: "Sign in",
						onClose: function (sAction) {
							if (sAction === "로그인") {
								self.getRouter().navTo("loginpage");
							}
						}
					}
				);
			} else {
				switch (key) {
				case 'participatefunding':
					sViewId = 'Participatefunding';
					break;
				case 'proceedfunding':
					sViewId = 'Proceedfunding';
					break;
				case 'runoutfunding':
					sViewId = 'Runoutfunding';
					break;
				case 'favoritefunding':
					sViewId = 'Favoritefunding';
					break;
				case 'approvebulletins':
					sViewId = 'Approvebulletins';
					break;
				}
				if (!sViewId) {
					return;
				}
				var oViewArea = this.getView().byId('viewArea');
				oViewArea.destroyContent();

				oViewArea.addContent(
					sap.ui.xmlview({
						viewName: 'SmartBrewer.RegistProject.view.mypage.' + sViewId
					})
				);
			}
		},

		onAfterRendering: function () {
			var self = this;

			// console.log($(".slideshow > img"))

			$(".slideshow > img").on('click', function (e) {
				console.log(e.target.id)
				console.log(self.getModel().getProperty('/imgData')[e.target.id - 1].PROJLI);

				window.open(self.getModel().getProperty('/imgData')[e.target.id - 1].PROJLI);

				// console.log($("#test123").attr('targetid'))
			})

		}
	});
});