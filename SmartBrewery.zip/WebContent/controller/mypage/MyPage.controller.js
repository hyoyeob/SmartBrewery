sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController',
	'sap/ui/model/json/JSONModel',
	"sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView"
], function (
	BaseController, JSONModel, VersionInfo, XMLView) {
	"use strict";
	return BaseController.extend("SmartBrewer.RegistProject.controller.mypage.MyPage", {

		onInit: function () {
			var self = this;

			if (this.getUserType() === "A") {
				this.getView().byId("blockManufact").setVisible(true);
				this.getView().byId("blockDeliver").setVisible(false);
			} else {
				this.getView().byId("blockManufact").setVisible(false);
				this.getView().byId("blockDeliver").setVisible(true);
			}

			if (this.getLoginCode() !== "S") {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.show(
					'로그인이 필요한 서비스입니다.', {
						title: "로그인",
						actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						initialFocus: "Sign in",
						onClose: function (sAction) {
							if (sAction === "로그인") {
								self.getRouter().navTo("loginpage");
							}
						}
					}
				);
			}
		},

		onItemSelect: function (oEvent) {
			var self = this;
			if (this.getLoginCode() !== "S") {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.show(
					'로그인이 필요한 서비스입니다.', {
						title: "로그인",
						actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						initialFocus: "Sign in",
						onClose: function (sAction) {
							if (sAction === "로그인") {
								self.getRouter().navTo("loginpage");
							}
						}
					}
				);
			} else {
				var key = oEvent.getSource().data('itemKey'),
					oOwner = this.getOwnerComponent();
				if (oOwner) {
					oOwner.getRouter().navTo(key);
					window.location.reload();
				}
			}
		}
	});
});