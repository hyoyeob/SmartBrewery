	sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController',
		'sap/ui/model/json/JSONModel',
		"sap/ui/VersionInfo",
		"sap/ui/core/mvc/XMLView",
		'SmartBrewer/RegistProject/model/formatter',
		'sap/m/MessageToast'
	], function (
		BaseController, JSONModel, VersionInfo, XMLView, formatter, MessageToast) {
		"use strict";

		var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";

		return BaseController
			.extend("SmartBrewer.RegistProject.controller.mypage.Approvebulletins", {
				formatter: formatter,

				onInit: function () {
					var self = this;
					var oModel = new JSONModel();

				let jsonData = {
							rfcData:{
								masterData :[]
							},
							layoutData : {
								
							}
						};
						var oModel = new JSONModel(jsonData);
						this.setModel(oModel)
						console.log(this.getModel().getProperty('/'))
						
						
					$.ajax({
						url: rfc_url,
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								"I_USERID": self.getUserId(),
								"I_SEARCH": "E"
							},
							function: "ZB_GET_FUNDIG_MYPAGE"
						}),
						dataType: 'json',
						success: function (res) {
							let I_DATA = res.exportData.I_DATA;
								console.log(self.getModel());
								// let masterData = {
								// 	I_DATA: I_DATA
								// }
								self.getModel().setProperty('/rfcData/masterData', I_DATA);
							},
							error: function (e) {
								MessageToast.show(e);
							}
						});
						
					},

				onItemSelect: function (oEvent) {
					var key = oEvent.getSource().data('itemKey') || oEvent.getSource().getParent().data('itemKey');

					var oParentView = this.getView().getParent();
					while (oParentView && !(oParentView instanceof sap.ui.core.mvc.XMLView)) {
						oParentView = oParentView.getParent();
					}
					if (oParentView) {
						var oOwner = oParentView.getController().getOwnerComponent();
						if (oOwner) oOwner.getRouter().navTo(key);
					}
				},

				onRefresh: function (oEvent) {
				var self = this;

						$.ajax({
							url: rfc_url,
							type: 'POST',
							contentType: 'application/json',
							data: JSON.stringify({
								importData: {
									"I_USERID": self.getUserId(),
									"I_SEARCH": "E"
								},
								function: "ZB_GET_FUNDIG_MYPAGE"
							}),
							dataType: 'json',
							success: function (res) {
								let I_DATA = res.exportData.I_DATA;
								console.log(I_DATA);
								self.getModel().setProperty('/rfcData/masterData', I_DATA);
								console.log(self.getModel().getProperty('/'))
							},
							error: function (e) {
								MessageToast.show(e);
							}
						});

					},

				linkopen: function (projid) {
					var self = this;
					var oModel = new JSONModel();
					var oParentView = this.getView().getParent();
					while (oParentView && !(oParentView instanceof sap.ui.core.mvc.XMLView)) {
						oParentView = oParentView.getParent();
					}
					sap.ui.getCore().setModel(oModel);
					sap.ui.getCore().getModel().setProperty('/projid', projid);
					if (oParentView) {
						var oOwner = oParentView.getController().getOwnerComponent();
						if (oOwner) oOwner.getRouter().navTo("editproject");
					}
				}
			});
	});