sap.ui.define([
	"sap/ui/core/Control",
], function (Control) {
	"use strict";

	var oImageSlider = Control.extend("com.test.iTest.controller.ImageSlider", {
		metadata: {
			properties: {
				width: {
					type: 'sap.ui.core.CSSSize',
					group: 'Appearance',
					defaultValue: '100%'
				},
				height: {
					type: 'sap.ui.core.CSSSize',
					group: 'Appearance',
					defaultValue: '200px'
				},
			},
			aggregations: {
				images: {
					type: 'sap.m.Image',
					multiple: true,
					singularName: 'images'
				}
			},
			events: {
				imagePress: {
					parameters: {
						targetId: {
							type: "string"
						}
					}
				}
			}
		},
		renderer: function (oRenderManager, oControl) {
			oRenderManager.write('<div id=\"' + oControl.getId() + '\" class=\"' + 'slideshow-wrapper' +
				'\" style=\"width:1080px;height:180px\">');
			oRenderManager.write('	<div id=\"' + oControl.getId() + '-slideshow\" class="slideshow" style=\"width:1080px;height:180px\">');
			oRenderManager.write(
				'		<img id="1" targetid="1" src="model/src/banner/pumpkin1.png"></img>'
			);
			oRenderManager.write(
				'		<img id="2" targetid = \"2\" src="model/src/banner/rose1.png"></img>'
			);

			oRenderManager.write(
				'		<img id="3" targetid = \"3\" src="model/src/banner/grape.png"></img>'
			);
			oRenderManager.write(
				'		<img id="4" targetid = \"4\" src="model/src/banner/strawberry1.png"></img>'
			);
			oRenderManager.write(
				'		<img id="5" targetid = \"5\" src="model/src/banner/banana.png"></img>'
			);
			oRenderManager.write('	</div>');
			oRenderManager.write('</div>');
			return oRenderManager;
		}
	});

	oImageSlider.prototype.onInit = function () {
		this.isFirst = true;
	};

	oImageSlider.prototype.onAfterRendering = function () {
		const NUMBER_OF_SLIDES = 5;
		var slide_width = document.getElementById(this.getId() + '-slideshow').scrollWidth / NUMBER_OF_SLIDES;
		var slide_number = 1,
			_self = this;
		this.$().find('img').off('click').on('click', function (oEvent) {
			_self.fireImagePress({
				targetId: oEvent.currentTarget.getAttribute('targetid')
			})
		});
		setInterval(function () {
			if (slide_number < NUMBER_OF_SLIDES) {
				//move to next slide
				$('#' + _self.getId() + '-slideshow').animate({
					scrollLeft: slide_width * slide_number
				}, 500);
				slide_number++;
			} else {
				//go to the first slide
				$('#' + _self.getId() + '-slideshow').animate({
					scrollLeft: 0
				}, 500);
				slide_number = 1;
			}
		}, 4500);
	};

	return oImageSlider;
});