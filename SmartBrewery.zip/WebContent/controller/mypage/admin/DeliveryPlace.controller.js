sap.ui.define([
	'SmartBrewer/RegistProject/controller/BaseController',
	'sap/ui/model/json/JSONModel',
	"sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView", 'jquery.sap.global', 'sap/ui/core/mvc/Controller', 'sap/m/MessageBox', 'sap/m/MessageToast'

], function (BaseController, JSONModel, VersionInfo, XMLView, jquery, Controller, MessageBox, MessageToast) {
	"use strict";

	var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";
	return BaseController.extend("SmartBrewer.RegistProject.controller.mypage.admin.DeliveryPlace", {

		onInit: function () {
			var self = this;
			var oModel = new JSONModel();
			let jsonData = {
				rfcData: {
					E_ZBLET0010: []
				}
			};

			//조회 RFC
			$.ajax({
				url: rfc_url,
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify({
					importData: {
						I_USERID: localStorage.getItem("UserId")
					},
					function: "ZB_GET_ADDR_DISPLAY"
				}),
				dataType: 'json',
				success: function (res) {
					console.log(res);
					if (res.exportData.E_CODE !== "E") {
						let E_ZBLET0010 = res.exportData.E_ZBLET0010;
						let rfcData = {
							E_ZBLET0010: E_ZBLET0010
						}
						self.getModel().setProperty('/rfcData', rfcData);

					}
					console.log(res);
				},
				error: function (e) {
					console.log(e)
				}
			})

			this.getModel(oModel);
			this.setModel(oModel);
			oModel.setData(jsonData);

		},
		rebindTable: function (oTemplate, sKeyboardMode) {
			this.oTable.bindRows({
				path: "/rfcData/E_ZBLET0010",
				template: oTemplate,
				key: "ADDRCO"
			});
		},

		// 행 추가
		addRow: function (evt) {
			var temp = {
				"USERID": localStorage.getItem("UserId")
			};
			var table = this.getModel().getProperty('/rfcData/E_ZBLET0010');
			if (table.length < 3) {
				table.push(temp);
				this.getModel().setProperty('/rfcData/E_ZBLET0010', table);
				this.getModel().getProperty('/rfcData/E_ZBLET0010');
			} else {
				MessageToast.show("등록 가능한 배송지를 초과했습니다.");
			}

		},

		// 삭제 RFC
		onDelete: function (oEvent) {
			var self = this;
			var oItem = oEvent.getSource();
			var oContext = oItem.getBindingContext();
			var sName = oContext.getProperty("bpfIndex");
			var I_ADDRCO = oContext.getProperty("ADDRCO");
			var btn_sid = oEvent.getSource().sId;
			var temp_array = btn_sid.split("-");
			var delete_index = temp_array[temp_array.length - 1];

			if (I_ADDRCO == undefined) {
				var table = this.getModel().getProperty('/rfcData/E_ZBLET0010');
				table.splice(delete_index, 1);
				console.log(table);
				this.getModel().setProperty('/rfcData/E_ZBLET0010', table);
				return;
			}
			var table = this.getModel().getProperty('/rfcData/E_ZBLET0010');
			table.splice(delete_index, 1);

			this.getModel().setProperty('/rfcData/E_ZBLET0010', table);
			$.ajax({
				url: rfc_url,
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify({
					importData: {
						I_USERID: localStorage.getItem("UserId"),
						I_ADDRCO: I_ADDRCO
					},
					function: "ZB_GET_ADDR_DELETE"
				}),
				dataType: 'json',
				success: function (res) {
					console.log(res);
					let E_ZBLET0010 = res.exportData.E_ZBLET0010;
					let rfcData = {
						E_ZBLET0010: E_ZBLET0010,
						E_CODE: res.exportData.E_CODE,
						E_MSG: res.exportData.E_MSG
					}
					self.getModel().setProperty('/rfcData', rfcData);
				},
				error: function (e) {
					console.log(e)
				}
			})
		},

		// 저장 버튼
		onSave: function (oEvent) {
			var self = this;
			var E_ZBLET0010 = self.getModel().getProperty('/rfcData/E_ZBLET0010');
			var table = this.getModel().getProperty('/rfcData/E_ZBLET0010');
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			sap.m.MessageBox.show(
				'정보를 저장하시겠습니까?', {
					title: "로그인",
					actions: ["저장", sap.m.MessageBox.Action.CLOSE],
					styleClass: bCompact ? "sapUiSizeCompact" : "",
					initialFocus: "Sign in",
					onClose: function (sAction) {
						if (sAction === "저장") {
							$.ajax({
								url: rfc_url,
								type: 'POST',
								contentType: 'application/json',
								data: JSON.stringify({
									importData: {
										I_USERID: localStorage.getItem("UserId"),
										E_ZBLET0010: E_ZBLET0010
									},
									function: "ZB_GET_ADDR_SAVE"
								}),
								dataType: 'json',
								success: function (res) {
									console.log(res);
									window.location.reload();
								},
								error: function (e) {
									console.log(e)
								}
							})
						}
					}
				}
			);

		},

	});
});