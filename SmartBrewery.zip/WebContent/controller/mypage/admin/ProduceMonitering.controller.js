sap.ui.define(
	['SmartBrewer/RegistProject/controller/BaseController',
		'sap/ui/model/json/JSONModel',
		"sap/ui/VersionInfo",
		"sap/ui/core/mvc/XMLView",
		'jquery.sap.global',
		'sap/ui/core/Fragment',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/Filter',
		'sap/m/MessageToast',
		'sap/m/MessageBox',
		"../../../model/formatter",
		"sap/m/Button"
	],
	function (BaseController, JSONModel, VersionInfo, XMLView, jQuery, Fragment, Controller, Filter, MessageToast, MessageBox,
		formatter, Button) {
		"use strict";

		return BaseController.extend(
			"SmartBrewer.RegistProject.controller.mypage.admin.ProduceMonitering", {
				formatter: formatter,

				onInit: function () {
					console.log('init');
					console.log(formatter.useynState('Y'))

					let T_ZBPPS0040;
					let rfcData;
					let jsonData = {
						rfcData: {
							T_ZBPPS0040: [],
							T_DATA: [],
							T_DATA_Handle: []
						},
						layoutData: {}
					};

					// ABAP 데이터 가져오기
					var self = this;
					var oModel = new JSONModel(jsonData);
					this.setModel(oModel);

					var oView = self.getView();

					$.ajax({
						url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {},
							function: "ZB_USEYN_STAT"
						}),
						dataType: 'json',
						success: function (res) {
							console.log('fisrt')
							self.getModel().setProperty('/rfcData/T_ZBPPS0040', res.exportData.T_ZBPPS0040)
							console.log(self.getModel().getProperty('/rfcData/T_ZBPPS0040'))

						},
						error: function (e) {
							MessageToast.show(e);
						}

					});

					// 팝업   
					$.ajax({
						url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {},
							function: "ZB_GET_TEMP"
						}),

						dataType: 'json',
						success: function (res) {
							console.log('2')
							console.log(res)

							self.getModel().setProperty('/rfcData/T_DATA', res.exportData.T_DATA)

							let T_DATA = self.getModel().getProperty('/rfcData/T_DATA')
							let errorData = [];

						},
						error: function (e) {
							MessageToast.show(e);
						}
					});

				},

				// 팝업 클릭 이벤트
				onSelect: function () {

					var oList = this.byId("gridList1"),
						oBinding = oList.getBinding("items");
					var item = oList.getSelectedItem();

					var selectIndex = oList.indexOfItem(item);

					var num = selectIndex + 1001

					var oModel3 = new JSONModel();

					$.ajax({
						url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_FERMID: num
							},
							function: 'ZB_GET_TEMP'
						}),
						dataType: 'json',
						success: function (res) {
							console.log('success')
							console.log(res)
							console.log(res.exportData.T_DATA)
							oModel3.setData(res);
						},
						error: function (e) {
							console.log('fail')
							console.log(e)
						}

					})
					this.getView().setModel(oModel3, "t");
					var viewObj = this.getView();

					//현우 다이얼로그
					if (this.byId("dlgUserImg")) {
						viewObj.removeDependent(this.byId("dlgUserImg"));
						this.byId("dlgUserImg").destroy();
					}

					Fragment.load({
							id: viewObj.getId(),
							name: "SmartBrewer.RegistProject.view.mypage.admin.manufacture",
							controller: this
						})
						.then(function (imgdlg) {
							console.log(imgdlg);
							viewObj.addDependent(imgdlg);
							imgdlg.setModel(oModel3);
							oList.removeSelections();
							imgdlg.open();
						});
				},
				onTest: function () {
					this.byId("dlgUserImg").close();
				},

				handleValueHelp: function () {
					var sInputValue = this.byId("productInput").getValue(),
						oModel = this.getView().getModel(),
						aProducts = oModel.getProperty("/ProductCollection");

					if (!this._oValueHelpDialog) {
						this._oValueHelpDialog = sap.ui.xmlfragment(
							"sap.m.sample.TableSelectDialog.ValueHelp",
							this
						);
						this.getView().addDependent(this._oValueHelpDialog);
					}

					aProducts.forEach(function (oProduct) {
						oProduct.selected = (oProduct.Name === sInputValue);
					});
					oModel.setProperty("/ProductCollection", aProducts);

					this._oValueHelpDialog.open();
				},

				handleValueHelpClose: function () {
					var oModel = this.getView().getModel(),
						aProducts = oModel.getProperty("/ProductCollection"),
						oInput = this.byId("productInput");

					var bHasSelected = aProducts.some(function (oProduct) {
						if (oProduct.selected) {
							oInput.setValue(oProduct.Name);
							return true;
						}
					});

					if (!bHasSelected) {
						oInput.setValue(null);
					}
				}

			});

	});