 sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController',
 	'sap/ui/model/json/JSONModel',
 	"sap/ui/VersionInfo",
 	"sap/ui/core/mvc/XMLView",
 	"sap/ui/core/mvc/Controller",
 	'jquery.sap.global',
 	'sap/ui/core/Fragment',
 	'sap/ui/model/Filter',
 	'sap/m/MessageToast',
 	'sap/m/MessageBox'

 ], function (BaseController, JSONModel, VersionInfo, XMLView, Controller, jQuery, Fragment, Filter, MessageToast, MessageBox) {
 	"use strict";

 	var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";

 	return BaseController
 		.extend("SmartBrewer.RegistProject.controller.mypage.Participatefunding", {

 			onInit: function (oEvent) {
 				var self = this;
 				var oModel = new JSONModel();
 				var jsonData = {};
 				$.ajax({
 					url: rfc_url,
 					type: 'POST',
 					contentType: 'application/json',
 					data: JSON.stringify({
 						importData: {
 							I_USERID: self.getUserId(),
 							I_SEARCH: "A"
 						},
 						function: "ZB_GET_FUNDIG_MYPAGE"
 					}),
 					dataType: 'json',
 					success: function (res) {
 						console.log(res);
 						var I_DATA = res.exportData.I_DATA;
 						var masterData = {
 							I_DATA: I_DATA
 						};
 						self.getModel().setProperty('/masterData', masterData);
 						console.log(masterData) 
 					},
 					error: function (e) {
 						MessageToast.show(e);
 					}
 				});
 				this.setModel(oModel);
 				oModel.setData(jsonData);
 				console.log(this);
 			},

 			onItemSelect: function (oEvent) {
 				var key = oEvent.getSource().data('itemKey') || oEvent.getSource().getParent().data('itemKey');

 				var oParentView = this.getView().getParent();
 				while (oParentView && !(oParentView instanceof sap.ui.core.mvc.XMLView)) {
 					oParentView = oParentView.getParent();
 				}
 				if (oParentView) {
 					var oOwner = oParentView.getController().getOwnerComponent();
 					if (oOwner) oOwner.getRouter().navTo(key);
 				}
 			},
 			onImagePress: function (oEvent) {
 				alert(oEvent.getParameter('targetId'));
 			},

 			onRefresh: function (refresh) {
 				var self = this;

 				$.ajax({
 					url: rfc_url,
 					type: 'POST',
 					contentType: 'application/json',
 					data: JSON.stringify({
 						importData: {
 							I_USERID: self.getUserId(),
 							I_SEARCH: "A"
 						},
 						function: "ZB_GET_FUNDIG_MYPAGE"
 					}),
 					dataType: 'json',
 					success: function (res) {
 						console.log(res);
 						var I_DATA = res.exportData.I_DATA;
 						var masterData = {
 							I_DATA: I_DATA
 						};
 						self.getModel().setProperty('/masterData', masterData);
 					},
 					error: function (e) {
 						MessageToast.show(e);
 					}
 				});
 			},

 			linkopen: function (url) {
 				window.open(url);
 			},
 			onImagePress : function(oEvent){
			alert(oEvent.getParameter('targetId'));
		}

 		});
 });