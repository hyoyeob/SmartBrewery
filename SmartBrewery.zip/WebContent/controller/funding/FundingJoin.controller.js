sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController', 'sap/ui/model/json/JSONModel',
		"sap/ui/VersionInfo", "sap/ui/core/mvc/XMLView", "sap/m/MessageBox", 'sap/ui/core/Fragment'
	],
	function (
		BaseController, JSONModel, VersionInfo, XMLView, MessageBox, Fragment) {
		"use strict";

		return BaseController.extend("SmartBrewer.RegistProject.controller.funding.FundingJoin", {

			onInit: function () {
				var self = this;
				if (sap.ui.getCore().getModel() === undefined) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.show(
						'주문 세션이 만료되었습니다.', {
							title: "세션 만료",
							actions: [sap.m.MessageBox.Action.CLOSE],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							onClose: function (sAction) {
								self.getRouter().navTo("projectlist");
							}
						}
					);
				}
			},
			onlistpage: function (oEvent) {
				var key = "projectlist",
					oOwner = this.getOwnerComponent();
				oOwner.getRouter().navTo(key);
			},
			oncheck: function (oEvent) {
				var self = this;
				var mo = this.getView().byId("fundingordemo").getValue();
				var pr = self.getOwnerComponent().getModel().getProperty('/PageData').E_PRESPR;
				var checkdata = {
					"checkmo": mo,
					"checkpr": (mo * pr)

				};
				self.getModel().setProperty('/checkdata', checkdata);

			},
			oninfopage: function (oEvent) {
				var projid = sap.ui.getCore().getModel().getProperty('/projid');
				var key = "projectdetail",
					oOwner = this.getOwnerComponent();
				oOwner.getRouter().navTo(key, {
					PROJID: projid
				});
			},
			onjoinfd: function (oEvent) {
				var self = this;
				var pr = self.getOwnerComponent().getModel().getProperty('/PageData').E_PRESPR;
				var mo = self.getView().byId("fundingordemo").getValue();
				var prmo = (pr * mo);

				$.ajax({
					url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_USERID: self.getUserId(),
							I_PROJID: sap.ui.getCore().getModel().getProperty('/projid'),
							I_ORDEMO: mo, //수량
							I_ORDEPR: prmo, //주문금액//////
							I_DELVAD: self.getView().byId("fundingaddrad").getValue(), // 주소
							I_DELVDE: self.getView().byId("fundingaddrde").getValue(), //상세주소
							I_DELVPO: self.getView().byId("fundingaddrpo").getValue(), //우편번호
							I_ADDREQ: self.getView().byId("fundingaddreq").getValue(), //배송 요청사항///////////
							I_DELVRE: self.getView().byId("fundingdelvre").getValue(), //추가 요청사항//////////
							I_DELVRC: self.getView().byId("fundingdelvrc").getValue(), //수령인 이름
							I_RCTELC: self.getView().byId("fundingrctelc").getValue(), //전화번호
							I_RCMOBN: self.getView().byId("fundingrcmobn").getValue() //휴대폰 번호//////////////
						},
						function: "ZB_FD_JOIN"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						var FundingJoin = {
							E_MSG: res.exportData.E_MSG,
							E_MAXORD: res.exportData.E_MAXORD,
							E_SUBRC: res.exportData.E_SUBRC,
						};
						var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;

						// console.log(FundingJoin.E_SUBRC);

						if (FundingJoin.E_SUBRC == "2") {
							// console.log(FundingJoin.E_SUBRC);
							console.log("test");
							sap.m.MessageBox.show(
								'주문량을 초과하였습니다.', {
									title: "주문실패",
									actions: [sap.m.MessageBox.Action.CLOSE],
									styleClass: bCompact ? "sapUiSizeCompact" : "",
									onClose: function (sAction) {

									}
								}
							);
						} else {

							sap.m.MessageBox.show(
								'주문이 완료되었습니다.', {
									title: "주문완료",
									actions: [sap.m.MessageBox.Action.CLOSE],
									styleClass: bCompact ? "sapUiSizeCompact" : "",
									onClose: function (sAction) {
										self.getRouter().navTo("projectlist");
										window.location.reload();
									}
								}
							);
						}

					},
					error: function (e) {
						MessageToast.show(e);
					}
				});

			},
			onOpenDialog: function (oEvnet) {

				var oModel = new JSONModel()
				var oView = this.getView();
				var self = this;
				if (!this.byId("addrSelect")) {
					Fragment.load({
						id: oView.getId(),
						name: "SmartBrewer.RegistProject.view.order.menu.AddrSelect",
						controller: this
					}).then(function (oDialog) {
						// connect dialog to the root view of this component (models, lifecycle)

						oView.addDependent(oDialog);
						oDialog.open();

					});
					var oModel = new JSONModel()

					let jsonData = {
						rfcData: {
							E_ADDRNM: [],
							E_ADDRPO: [],
							E_ADDRAD: [],
							E_RESULT: [],
							E_MSG: []
						},
						layoutData: {}

					};
					$.ajax({
						url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_USERID: self.getUserId()
							},
							function: "ZB_GET_ADDR",
						}),
						dataType: 'json',
						success: function (res) {

							var addrData = {
								ADDRLST: res.exportData.T_ZBSDS0020
							}
							self.getView().getModel().setProperty('/addrData', addrData);
							// self.getModel().setProperty('/rfcData', self.getOwnerComponent().getModel().getProperty('/rfcData'));
							// this.setModel(oModel, "Addrlist");

						},
						error: function (e) {
							MessageToast.show(e);
						}
					});

				} else {
					this.byId("addrSelect").open();
				}

			},

			onOpenDialog2: function (oEvnet) {
				var oModel = new JSONModel()
				var oView = this.getView();
				var self = this;
				if (!this.byId("addrInput")) {
					Fragment.load({
						id: oView.getId(),
						name: "SmartBrewer.RegistProject.view.order.menu.AddrInput",
						controller: this
					}).then(function (oDialog) {
						// connect dialog to the root view of this component (models, lifecycle)

						oView.addDependent(oDialog);
						oDialog.open();

					})
				} else {
					this.byId("Addr").open();
				}

			},
			onSearch: function (page) {
				var oModel = new JSONModel()
				var oView = this.getView();
				var self = this;
				$.ajax({
					url: "https://www.juso.go.kr/addrlink/addrLinkApiJsonp.do",
					type: "post",
					data: {
						resultType: 'json',
						returnUrl: 'https://webidecp-z1zug0uysb.dispatcher.jp1.hana.ondemand.com/', //호출한 화면 (AddrInput.fragment.xml 주소)
						currentPage: page,
						countPerPage: 10,
						keyword: self.byId('input0').getValue(),
						//'체육관로',
						currentPageRoad: page,
						countPerPageRoad: 10,
						resultTypeRoad: 'json',
						keywordRoad: self.byId('input0').getValue(),
						//'체육관로',
						roadAddr: '',
						bdNm: '',
						roadAddrPart1: '',
						bdKdcd: '',
						roadAddrPart2: '',
						siNm: '',
						engAddr: '',
						sggNm: '',
						jibunAddr: '',
						emdNm: '',
						zipNo: '',
						liNm: '',
						admCd: '',
						rn: '',
						rnMgtSn: '',
						udrtYn: '',
						bdMgtSn: '',
						buldMnnm: '',
						buldSlno: '',
						detBdNmList: '',
						mtYn: '',
						emdNo: '',
						lnbrMnnm: '',
						lnbrSlno: '',
						confmKey: 'devU01TX0FVVEgyMDE5MTEwOTE2NDU0NTEwOTE4MDg='
					},
					dataType: "jsonp",
					success: function (jsonStr) {
						self.getView().getModel().setProperty('/jsonStr', jsonStr);

						var addrData = {
							ADDRLST: self.byId("table0").getModel().getProperty('/jsonStr/results/juso')
						}
						self.getView().getModel().setProperty('/addrData', addrData);
					},
					error: function (xhr, status, error) {
						alert("에러발생");
					}
				});
			},
			onClose2: function () {
				this.byId("Addr").close();
				this.byId("Addr").destroy();
			},
			onOK2: function (oEvent) {
				var self = this;
				var selectedRow = self.getView().byId("table0").getSelectedIndices();
				var addrData = {
					ADDRLST: [{
						ADDRAD: self.byId("table0").getModel().getProperty('/jsonStr/results/juso')[selectedRow[0]].roadAddr,
						ADDRPO: self.byId("table0").getModel().getProperty('/jsonStr/results/juso')[selectedRow[0]].zipNo
					}]
				};

				self.getModel().setProperty('/addrData', addrData);

				console.log(addrData)
				console.log(self.byId("table0").getModel().getProperty('/addrData'))

				var selectAddr = self.byId("table0").getModel().getProperty('/addrData/ADDRLST');
				console.log(selectAddr)
				self.getView().getModel().setProperty('/selectData', selectAddr[0]);
				console.log(selectAddr[0])
				this.byId("Addr").close();
				this.byId("Addr").destroy();
			},

			onOk: function (oEvent) {

				this.byId("addrSelect").getModel().getProperty('/addrData');
				var selectedRow = this.getView().byId("frgTable").getSelectedIndices();
				var aa = this.byId("frgTable").getModel().getProperty('/addrData/ADDRLST');
				this.getView().getModel().setProperty('/selectData', aa[selectedRow]);

				this.byId("addrSelect").close();

			},
			onClose: function () {

				this.byId("addrSelect").close();

			},

		});

	});