sap.ui.define(['./BaseController', 'sap/ui/model/json/JSONModel',
	'sap/ui/Device', 'SmartBrewer/RegistProject/model/formatter',
	'sap/m/Link', 'sap/m/MessageToast', 'sap/ui/core/mvc/Controller',
	'sap/m/Button', 'sap/ui/core/CustomData', "sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView"
], function (BaseController, JSONModel,
	Device, formatter, Link, MessageToast, Controller, Button, CustomData, VersionInfo, XMLView) {
	"use strict";
	return BaseController.extend("SmartBrewer.RegistProject.controller.Home", {
		formatter: formatter,

		onInit: function () {
			var oViewModel = new JSONModel({
				isPhone: Device.system.phone
			});
			this.setModel(oViewModel, "view");
			Device.media.attachHandler(function (oDevice) {
				this.getModel("view").setProperty("/isPhone",
					oDevice.name === "Phone");
			}.bind(this));
			this.interverGallery();
		},

		interverGallery: function () {
			var self = this;
			setInterval(function () {
				self.getView().byId("idCarousel").next();
			}, 4500);
		},

		onItemSelect: function (oEvent) {
			var key = oEvent.getSource().data('itemKey'),
				oOwner = this.getOwnerComponent();
			if (this.getLoginCode() !== "S" && key === "myorder" || this.getLoginCode() !== "S" &&
				key === "registproject") {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.show(
					'로그인이 필요한 서비스입니다.', {
						title: "로그인",
						actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						initialFocus: "Sign in",
						onClose: function (sAction) {
							if (sAction === "로그인") {
								self.getRouter().navTo("loginpage");
							}
						}
					}
				);
			} else if (oOwner) {
				oOwner.getRouter().navTo(key);
			}
		}
	});
});