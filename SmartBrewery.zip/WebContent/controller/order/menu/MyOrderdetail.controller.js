sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController',
	'sap/ui/model/json/JSONModel',
	"sap/m/Button",
	"sap/m/Text",
	"sap/m/Label",
	"sap/m/Input",
	"sap/ui/VersionInfo",
	'sap/m/MessageToast',
	"sap/m/Dialog",
	"sap/ui/core/mvc/XMLView",
	'sap/ui/model/Filter',
	'sap/m/MessageBox',
	'sap/ui/core/Fragment'
], function (
	BaseController, JSONModel, Button, Text, Label, Input, VersionInfo, MessageToast, Dialog, XMLView, Filter, MessageBox, Fragment) {
	"use strict";
	var oSignModel = new JSONModel();
	var self = this;
	/*   var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";*/
	return BaseController.extend("SmartBrewer.RegistProject.controller.order.menu.MyOrderdetail", {

		onInit: function () {
			var self = this;
			var oModel = new JSONModel();

			//주문번호 가져오기
			var test = self.getOwnerComponent().getModel("test");
			console.log("test");
			console.log(test);

			var ordeid = test.getProperty('/layoutData/ordeid');
			console.log(ordeid);
			var ordeno = test.getProperty('/layoutData/ordeno');
			console.log(ordeno);

			let jsonData = {
				rfcData: {},
				layoutData: {}
			};

			$.when(self.rfcCall("ZB_SD_DETAIL_SEARCH", ordeid, ordeno), self.rfcCall("ZB_ORDEID_DISPLAY", ordeid, ordeno)).done(function (
				result1, result2) {

				console.log(result1, result2)
				let E_MSG = result2.E_MSG
				let E_RESULT = result2.E_RESULT
				let E_VAL01 = result2.E_VAL01
				let E_VAL02 = result2.E_VAL02
				let E_MSG1 = result1.E_MSG1
				let E_RESULT1 = result1.E_RESULT1
				let E_ORDEID = result1.E_ORDEID
					// let E_PROJNM = result1.E_PROJNM
				let E_ORDEMO = result1.E_ORDEMO
				let E_ORDEPR = result1.E_ORDEPR
				let E_MANUST_TEXT = result1.E_MANUST_TEXT
				let E_DEADDR = result1.E_DEADDR
				let E_DETIME = result1.E_DETIME
				let E_DCARDR = result1.E_DCARDR
				let E_WATEMO = result1.E_WATEMO
				let E_YEASTC = result1.E_YEASTC
				let E_YEASTM = result1.E_YEASTM
				let E_NURUCD = result1.E_NURUCD
				let E_NURUMO = result1.E_NURUMO
				let E_RICEMO = result1.E_RICEMO
				let E_SUGACD = result1.E_SUGACD
				let E_SUGAMO = result1.E_SUGAMO
				let E_ALCHPE = result1.E_ALCHPE
				let E_SCDTEM = result1.E_SCDTEM
				let E_FCDTEM = result1.E_FCDTEM
				let E_SCDMIX = result1.E_SCDMIX
				let E_FCDMIX = result1.E_FCDMIX
				let E_COLORC = result1.E_COLORC
				let E_ADDREQ = result1.E_ADDREQ
				let E_ADDINM = result1.E_ADDINM
				let E_STERTF = result1.E_STERTF

				// let E_RESULT2 = result3.E_RESULT2
				// let E_MSG2 = result3.E_MSG2

				let rfcData = {
					E_MSG: E_MSG,
					E_RESULT: E_RESULT,
					E_MSG1: E_MSG1,
					E_RESULT1: E_RESULT1,
					E_VAL01: E_VAL01,
					E_VAL02: E_VAL02,
					E_ORDEID: E_ORDEID,
					// E_PROJNM: E_PROJNM,
					E_ORDEMO: E_ORDEMO,
					E_ORDEPR: E_ORDEPR,
					E_MANUST_TEXT: E_MANUST_TEXT,
					E_DEADDR: E_DEADDR,
					E_DETIME: E_DETIME,
					E_DCARDR: E_DCARDR,
					E_WATEMO: E_WATEMO,
					E_YEASTC: E_YEASTC,
					E_YEASTM: E_YEASTM,
					E_NURUCD: E_NURUCD,
					E_NURUMO: E_NURUMO,
					E_RICEMO: E_RICEMO,
					E_SUGACD: E_SUGACD,
					E_SUGAMO: E_SUGAMO,
					E_ALCHPE: E_ALCHPE,
					E_SCDTEM: E_SCDTEM,
					E_FCDTEM: E_FCDTEM,
					E_SCDMIX: E_SCDMIX,
					E_FCDMIX: E_FCDMIX,
					E_COLORC: E_COLORC,
					E_ADDREQ: E_ADDREQ,
					E_ADDINM: E_ADDINM,
					E_STERTF: E_STERTF
						// E_RESULT2: E_RESULT2,
						// E_MSG2: E_MSG2
				}
				console.log(rfcData);
				console.log(result1, result2);
				if (E_RESULT1 === 'E') {
					self.getView().byId("map").setEnabled(false);
				}
				self.getModel().setProperty('/rfcData', rfcData); //고려해봐야할 사항

			}).fail(function (error) {
				console.log(error);
			})
			this.getModel(oModel);
			this.setModel(oModel);
			oModel.setData(jsonData);

		},

		rfcCall: function (RfcName, ordeid, ordeno) {

			var deferred = $.Deferred(); //deferred 객체 생성

			try {
				//주문번호 가져오기 

				$.ajax({
					url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_ORDEID: ordeid,
							I_ORDENO: ordeno
						},
						function: RfcName
					}),
					dataType: 'json',
					success: function (res) {

						deferred.resolve(res.exportData);

						console.log(res);

					},
					error: function (e) {
						console.log(e);
					}
				})

			} catch (err) {
				deferred.reject(err);
			} //실패했을 때 reject 호출 -> fail로 연결
			return deferred;
		},
		changeORDEID: function (oEvent) {
			let ORDEID = oEvent.getSource().getValue()
			console.log('change')
			console.log(ordeid1)
			this.getView().getModel().setProperty('/layoutData/I_ORDEID', ordeid1)
		},

		changeORDENO: function (oEvent) {
			let ORDENO = oEvent.getSource().getValue()
			console.log('change')
			console.log(ordeno1)
			this.getView().getModel().setProperty('/layoutData/I_ORDENO', ordeno1)
		},

		onBack: function () {
			console.log(this.getView());
			console.log("제발");
			// this.getOwnerComponent().myNavBack();
			this.getRouter().navTo("myorderlist");
			window.location.reload();

		},

		// var oView = this.getView();
		// var orderfragment = new orderfragment();
		//위치추적 팝업 펑션
		onCancle: function () {
			var self = this;
			var test = self.getOwnerComponent().getModel("test");
			console.log("test");
			console.log(test);
			var ordeid1 = test.getProperty('/layoutData/ordeid');
			console.log(ordeid1);
			var ordeno1 = test.getProperty('/layoutData/ordeno');
			console.log(ordeno1);

			console.log("onCancle")

			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.confirm(
				'주문을 취소하시겠습니까?', {
					icon: MessageBox.Icon.CONFIRM,
					title: "주문 취소",
					actions: [MessageBox.Action.YES, MessageBox.Action.NO, ],
					styleClass: bCompact ? "sapUiSizeCompact" : "",

					onClose: function (sAction) {

						console.log(this);
						//MessageToast.show("Action selected: " + sAction);

						console.log(sAction);

						if (sAction === "YES") {
							console.log("저장버튼 누름")
							var self = this;

							//취소플래그에 x를 넣어주는 구문
							//var self = this;

							$.ajax({
								url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
								type: 'POST',
								contentType: 'application/json',
								data: JSON.stringify({
									importData: {
										I_ORDEID: ordeid1,
										I_ORDENO: ordeno1

									},
									function: "ZB_CANC_ORDER_NO"
								}),

								dataType: 'json',
								success: function (res) {
									console.log(res)
									oSignModel.setData(res);
									console.log(oSignModel);
									console.log("저장버튼 눌렀음");
									var msg = res.exportData.E_MSG2;
									var result = res.exportData.E_RESULT2;

									console.log(result + msg);

									if (result === "S") {

										MessageBox.success(msg);
									} else {

										MessageBox.warning(msg);
									}

								},
								error: function (e) {
									console.log(e);
									//oDialog.close();
								}
							});

						} else {
							console.log("취소버튼 누름")

						}

					}.bind(this)

				}
			);

		},
		// var self = this;
		// var oView = self.getView());
		//

		onMap: function (oEvent) {
			var self = this;
			var oView = self.getView();
			var E_VAL01 = self.getModel().getProperty("/rfcData/E_VAL01");
			var E_VAL02 = self.getModel().getProperty("/rfcData/E_VAL02");
			console.log(E_VAL01)
			console.log(E_VAL02)
			if (!self._oDialog) {
				self._oDialog = new sap.m.Dialog({
					title: '현재 위치',
					contentWidth: '1000px',
					contentHeight: '500px',
					afterOpen: function () {
						var mapContainer = document.getElementById('map'), // 지도를 표시할 div          
							mapOption = {
								center: new kakao.maps.LatLng(E_VAL01, E_VAL02), // 지도의 중심좌표
								level: 3 // 지도의 확대 레벨
							};

						var map = new kakao.maps.Map(mapContainer, mapOption); // 지도를 생성합니다

						// 마커가 표시될 위치입니다 
						var markerPosition = new kakao.maps.LatLng(E_VAL01, E_VAL02);

						// 마커를 생성합니다
						var marker = new kakao.maps.Marker({
							position: markerPosition
						});

						marker.setMap(map);
						self._oDialog._mapMarker = marker;
					}
				});
			}
			self._oDialog.destroyContent();
			self._oDialog.addContent(
				new sap.ui.core.HTML({
					content: '<div id="map" style="width:100%;height:350px;"></div>'
				})
			);
			self._oDialog.open();

		}

	});
});