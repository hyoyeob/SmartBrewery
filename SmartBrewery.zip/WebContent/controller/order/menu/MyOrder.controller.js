sap.ui.define(
	['SmartBrewer/RegistProject/controller/BaseController', 'sap/ui/model/json/JSONModel',
		"sap/ui/VersionInfo", "sap/ui/core/mvc/XMLView",
		'jquery.sap.global', 'sap/ui/core/Fragment',
		'sap/ui/core/mvc/Controller', 'sap/ui/model/Filter', 'sap/m/MessageToast',
		'sap/m/MessageBox'
	],
	function (BaseController, JSONModel, VersionInfo, XMLView,
		jQuery, Fragment, Controller, Filter, MessageToast, MessageBox) {
		"use strict";

		var err_flag = false;
		var imglnk = "";
		var pressDialog;
		var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";
		return BaseController.extend("SmartBrewer.RegistProject.controller.order.menu.MyOrder", {

			onInit: function () {
				var self = this;
				if (this.getLoginCode() !== "S") {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.show(
						'로그인이 필요한 서비스입니다.', {
							title: "로그인",
							actions: ["로그인", sap.m.MessageBox.Action.CLOSE],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							initialFocus: "Sign in",
							onClose: function (sAction) {
								if (sAction === "로그인") {
									self.getRouter().navTo("loginpage");
								} else {
									self.getRouter().navTo("home");
								}
							}
						}
					);
				} else {

					var oModel = new JSONModel();
					var jsonData = {
						rfcData: {
							T_REGFORM: [],
							ADD_TABLE: []
						}
					};
					$.ajax({
						url: rfc_url,
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {},
							function: "ZB_GET_ADDI_LIST"
						}),
						dataType: 'json',
						success: function (res) {
							console.log(res);
							var ADDLST = res.exportData.T_ZBSDT0030;
							$.each(ADDLST, function (index, oData) {
								oData.CODE = index + '';
							});

							var masterData = {
								ADDLST: ADDLST,
								IMG: [{
									key: "01",
									title: "1번 병",
									image: "model/src/bottle/bottle_1.png"
								}, {
									key: "02",
									title: "2번 병",
									image: "model/src/bottle/bottle_2.png"
								}, {
									key: "03",
									title: "3번 병",
									image: "model/src/bottle/bottle_3.png"
								}, {
									key: "04",
									title: "4번 병",
									image: "model/src/bottle/bottle_4.png"
								}],
								NURLST: [{
									GROUP: "NUR",
									NURUCD: "01",
									VALUE: "백미"
								}, {
									GROUP: "NUR",
									NURUCD: "02",
									VALUE: "현미"
								}, {
									GROUP: "NUR",
									NURUCD: "03",
									VALUE: "보리"
								}],
								YSTLST: [{
									GROUP: "YST",
									YEASTC: "01",
									VALUE: "이스트"
								}],
								SUGLST: [{
									GROUP: "SUG",
									SUGACD: "01",
									VALUE: "올리고당"
								}, {
									GROUP: "SUG",
									SUGACD: "02",
									VALUE: "물엿"
								}, {
									GROUP: "SUG",
									SUGACD: "03",
									VALUE: "조청"
								}],
								COLLST: [{
									GROUP: "COL",
									COLORC: "01",
									VALUE: "빨간색"
								}, {
									GROUP: "COL",
									COLORC: "02",
									VALUE: "노란색"
								}, {
									GROUP: "COL",
									COLORC: "03",
									VALUE: "살구색"
								}, {
									GROUP: "COL",
									COLORC: "04",
									VALUE: "보라색"
								}, {
									GROUP: "COL",
									COLORC: "05",
									VALUE: "갈색"
								}]
							};
							self.getView().setModel(oModel, 'jsonData');
							self.getModel().setProperty('/masterData', masterData);
						},
						error: function (e) {
							MessageToast.show(e);
						}
					});

					setTimeout(() => {
						//      console.log(self.getUserId());
					}, 1000)

					//         console.log(this.getView().byId("phoneNumberInput").getValue().getValueState(sState));

					this.getModel(oModel);
					this.setModel(oModel);
					oModel.setData(jsonData);
				}
			},
			// uploadImageByImgur: function (file, callback) {
			//    form = new FormData();
			//    form.append('image', file);
			//    $.ajax({
			//       xhr: function () {
			//          var xhr = new window.XMLHttpRequest();
			//          xhr.upload.addEventListener("progress", function (evt) { // 업로드상태이벤트리스너등록
			//             if (evt.lengthComputable) {
			//                console.log("업로드진행률:" + parseInt((evt.loaded / evt.total * 100), 10) + "%");
			//             }
			//          }, false);
			//          return xhr;
			//       },
			//       url: 'https://api.imgur.com/3/image', // 업로드요청주소             
			//       headers: {
			//          Authorization: 'Client-ID 발급받은클라이언트아이디'
			//       },
			//       type: 'POST',
			//       data: form,
			//       cache: false,
			//       contentType: false,
			//       processData: false
			//    }).always(callback);
			// },

			selectCount: function (oEvent) {
				let changeKey = oEvent.getSource().getSelectedKey() //12345
					// this.getModel().getProperty('/masterData/IMG')
				this.getModel().setProperty('/layoutData/selectedKey', changeKey);
			},

			selectCount2: function (oEvent) {
				var self = this;
				let changeKey2 = oEvent.getSource().getSelectedKey() //12345
					//            console.log(self.getModel().getProperty('/masterData'));
				var img = self.getModel().getProperty('/masterData/IMG').filter(function (status) {
					return status.key == changeKey2
				});

				this.getView().byId("BottleImagePreview").setSrc(img[0]["image"]);
			},

			onAdd: function (evt) {
				console.log(this.getModel().getProperty('/rfcData/ADD_TABLE'))
				var table = this.getModel().getProperty('/rfcData/ADD_TABLE');
				table.push({});
				this.callTable(this);
			},

			onDelete: function (oEvent) {
				var table = this.getModel().getProperty('/rfcData/ADD_TABLE');
				var addTable = this.getView().byId('AdditiveInputTable');
				var selectedNum = addTable.getSelectedIndices();

				$.each(selectedNum.reverse(), function (index, indexValue) {
					table.splice(indexValue, 1);
				});
				this.getModel().setProperty('/rfcData/ADD_TABLE', table);
				addTable.clearSelection();
			},

			callTable: function (self) {
				var table = self.getModel().getProperty('/rfcData/ADD_TABLE');
				var addTable = self.getView().byId('AdditiveInputTable');
				var ADD_TABLE = [];

				for (var i = 0; i < table.length; i++) {
					ADD_TABLE.push({
						"ADDICD": addTable.getRows()[i].getCells()[0].getSelectedKey(),
						"ADDIMO": addTable.getRows()[i].getCells()[1].getValue()
							//            "USERID": I_USERID

					});
				}
				self.getModel().setProperty('/rfcData/ADD_TABLE', ADD_TABLE);

			},

			getData: function () {
				console.log(this);
				var self = this;
				if (self.byId("SterilizationInput").getSelectedIndex() === 0) {
					var STERTF = 'X';
				}
				var I_DATA = [{
					DELVAD: self.byId("AddressInput").getValue(),
					DELVDE: self.byId("AdressDetailInput").getValue(),
					DELVPO: self.byId("AdressNumberInput").getValue(),
					DELVRC: self.byId("RecipientInput").getValue(),
					DELVRE: self.byId("DeliveryRequirementInput").getValue(),
					ORDEMO: self.byId("VolumeOfOrdersInput").getValue(),
					ORDEPR: self.byId("PriceInput").getValue(),
					USERID: self.getUserId(),
					RCMOBN: self.byId("phoneNumberInput").getValue(),
					RCTELC: self.byId("NumberInput").getValue(),
					WATEMO: self.byId("WaterAmountInput").getValue(),
					YEASTC: self.byId("YeastTypeInput").getSelectedKey(),
					YEASTM: self.byId("YeastAmountInput").getValue(),
					NURUCD: self.byId("NurukTypeInput").getSelectedKey(),
					NURUMO: self.byId("NurukAmountInput").getValue(),
					RICEMO: self.byId("RiceAmountInput").getValue(),
					SUGACD: self.byId("SugarTypeInput").getSelectedKey(),
					SUGAMO: self.byId("SugarAmountInput").getValue(),
					ALCHPE: self.byId("AlcAmountInput").getValue(),
					FSTTEM: self.byId("FstTempInput").getValue(),
					SCDTEM: self.byId("ScdTempInput").getValue(),
					FSTMIX: self.byId("FstMixInput").getValue(),
					SCDMIX: self.byId("ScdMixInput").getValue(),
					ADDREQ: self.byId("AdditionalRequirementsInput").getValue(),
					BOTTTY: self.byId("BottleTypeInput").getSelectedKey(),
					COLORC: self.byId("ColorTypeInput").getSelectedKey(),
					STERTF: STERTF
						// CURRCY: "KRW"

				}];
				console.log('idata')
				console.log(I_DATA);
				self.callTable(self);
				var I_ZBSDT0050 = self.getModel().getProperty('/rfcData/ADD_TABLE');

				$.ajax({
					url: rfc_url,
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_DATA: I_DATA,
							I_ZBSDT0050: I_ZBSDT0050
						},
						function: "ZB_GET_ORDER01"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						console.log(res.exportData.E_ORDEID);
						$.ajax({
							url: rfc_url,
							type: 'POST',
							contentType: 'application/json',
							data: JSON.stringify({
								importData: {
									I_ORDEID: res.exportData.E_ORDEID,
									I_SEQ: "04",
									I_IMGLNK: imglnk
								},
								function: "ZB_SET_PROJECT_IMAGE"
							}),
							dataType: 'json',
							success: function (res) {
								console.log(res);
								var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;
								sap.m.MessageBox.show(
									'주문이 완료되었습니다.', {
										title: "주문완료",
										actions: [sap.m.MessageBox.Action.CLOSE],
										styleClass: bCompact ? "sapUiSizeCompact" : "",
										onClose: function (sAction) {
											self.getRouter().navTo("productlist");
											window.location.reload();
										}
									}
								);
							},
							error: function (e) {}
						});
					},
					error: function (e) {
						oDialog.close();
					}
				});
			},
			onAddressInput: function (oEvent) {
				var oModel = new JSONModel()
				var oView = this.getView();
				var self = this;
				if (!this.byId("addrInput")) {
					Fragment.load({
						id: oView.getId(),
						name: "SmartBrewer.RegistProject.view.order.menu.AddrInput",
						controller: this
					}).then(function (oDialog) {
						// connect dialog to the root view of this component (models, lifecycle)

						oView.addDependent(oDialog);
						oDialog.open();

					})
				} else {
					this.byId("Addr").open();
				}
			},

			onSearch: function (page) {
				var oModel = new JSONModel()
				var oView = this.getView();
				var self = this;
				$.ajax({
					url: "https://www.juso.go.kr/addrlink/addrLinkApiJsonp.do",
					type: "post",
					data: {
						resultType: 'json',
						returnUrl: 'https://webidecp-z1zug0uysb.dispatcher.jp1.hana.ondemand.com/', //호출한 화면 (AddrInput.fragment.xml 주소)
						currentPage: page,
						countPerPage: 10,
						keyword: self.byId('input0').getValue(),
						//'체육관로',
						currentPageRoad: page,
						countPerPageRoad: 10,
						resultTypeRoad: 'json',
						keywordRoad: self.byId('input0').getValue(),
						//'체육관로',
						roadAddr: '',
						bdNm: '',
						roadAddrPart1: '',
						bdKdcd: '',
						roadAddrPart2: '',
						siNm: '',
						engAddr: '',
						sggNm: '',
						jibunAddr: '',
						emdNm: '',
						zipNo: '',
						liNm: '',
						admCd: '',
						rn: '',
						rnMgtSn: '',
						udrtYn: '',
						bdMgtSn: '',
						buldMnnm: '',
						buldSlno: '',
						detBdNmList: '',
						mtYn: '',
						emdNo: '',
						lnbrMnnm: '',
						lnbrSlno: '',
						confmKey: 'devU01TX0FVVEgyMDE5MTEwOTE2NDU0NTEwOTE4MDg='
							//'devU01TX0FVVEgyMDE5MTEwODE5MDYzMzEwOTE3OTk='          //  집에꺼    이거 자리 옮기면 다시 신청해서 받아야함 
							//'devU01TX0FVVEgyMDE5MTEwODE3MzA0NzEwOTE3OTc=',        //학교내자리        // https://www.juso.go.kr/addrlink/devAddrLinkRequestWrite.do?returnFn=write&cntcMenu=URL
					}, // 여기 사이트로 들어가서 신청하면 바로 받아짐
					dataType: "jsonp",
					success: function (jsonStr) {
						self.getView().getModel().setProperty('/jsonStr', jsonStr);

						var addrData = {
							ADDRLST: self.byId("table0").getModel().getProperty('/jsonStr/results/juso')
						}
						self.getView().getModel().setProperty('/addrData', addrData);

						//       roadAddr: "부산광역시 서구 망양로 231 (동대신동1가, 혜광주택)"
						//       roadAddrPart1: "부산광역시 서구 망양로 231"
						//       zipNo: "49214"  우편번호
						//       console.log(self.getView().getModel().getProperty('/jsonStr/results/juso/0/emdNm')) // 여기서 찾아짐
					},
					error: function (xhr, status, error) {
						alert("에러발생");
					}
				});
			},

			onCheck: function (oEvent) {
				var self = this;
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.confirm(

					"해당 정보로 주문하시겠습니까?", {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction === "OK") {
								if (err_flag == true) {
									MessageBox.show("올바른 값을 입력해주세요");
								} else if (self.getView().byId("AdressDetailInput").getValue() === "" || self.getView().byId("VolumeOfOrdersInput").getValue() ===
									"" || self.getView().byId("RecipientInput").getValue() === "" || self.getView().byId("phoneNumberInput").getValue() === "" ||
									self.getView().byId("AddressInput").getValue() === "") {
									MessageBox.show("필요한 값을 모두 입력해주세요");
								} else {
									self.getData();
								}
							}
						}
					}
				);
			},

			onOpenDialog: function (oEvnet) {

				var oModel = new JSONModel()
				var oView = this.getView();
				var self = this;
				if (!this.byId("addrSelect")) {
					Fragment.load({
						id: oView.getId(),
						name: "SmartBrewer.RegistProject.view.order.menu.AddrSelect",
						controller: this
					}).then(function (oDialog) {
						// connect dialog to the root view of this component (models, lifecycle)

						oView.addDependent(oDialog);
						oDialog.open();

					});
					var oModel = new JSONModel()

					let jsonData = {
						rfcData: {
							E_ADDRNM: [],
							E_ADDRPO: [],
							E_ADDRAD: [],
							E_RESULT: [],
							E_MSG: []
						},
						layoutData: {}
					};
					$.ajax({
						url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_USERID: self.getUserId()
							},
							function: "ZB_GET_ADDR",
						}),
						dataType: 'json',
						success: function (res) {
							console.log(res);
							var addrData = {
								ADDRLST: res.exportData.T_ZBSDS0020
							}
							self.getView().getModel().setProperty('/addrData', addrData);

							// this.setModel(oModel, "Addrlist");

						},
						error: function (e) {
							MessageToast.show(e);
						}
					});

				} else {
					this.byId("addrSelect").open();
				}

			},
			onClose: function () {

				this.byId("addrSelect").close();

			},
			onClose2: function () {
				this.byId("Addr").close();
				this.byId("Addr").destroy();
			},
			onOK2: function (oEvent) {
				var self = this;
				var selectedRow = self.getView().byId("table0").getSelectedIndices();
				var addrData = {
					ADDRLST: [{
						ADDRAD: self.byId("table0").getModel().getProperty('/jsonStr/results/juso')[selectedRow[0]].roadAddr,
						ADDRPO: self.byId("table0").getModel().getProperty('/jsonStr/results/juso')[selectedRow[0]].zipNo
					}]
				};

				self.getModel().setProperty('/addrData', addrData);

				//       self.getView().setModel(oModel, 'jsonData');

				console.log(addrData)
				console.log(self.byId("table0").getModel().getProperty('/addrData'))

				var selectAddr = self.byId("table0").getModel().getProperty('/addrData/ADDRLST');
				console.log(selectAddr)
				self.getView().getModel().setProperty('/selectData', selectAddr[0]);
				console.log(selectAddr[0])
				this.byId("Addr").close();
				this.byId("Addr").destroy();
			},
			onOk: function (oEvent) {

				this.byId("addrSelect").getModel().getProperty('/addrData');
				var selectedRow = this.getView().byId("frgTable").getSelectedIndices();
				//         console.log(this.byId("addrSelect").getModel().getProperty('/addrData').getRows()[selectedRow])
				var selectAddr = this.byId("frgTable").getModel().getProperty('/addrData/ADDRLST');
				console.log(selectAddr)
				this.getView().getModel().setProperty('/selectData', selectAddr[selectedRow]);

				console.log(this.getView().getModel()); // 모델 못가져옴

				console.log(selectAddr[selectedRow]);
				this.byId("addrSelect").close();
				//      var bb = aa[selectedRow]];
				//         console.log(aa.getRows()[selectedRow])

				//       console.log(this.byId("addrSelect").getModel().getProperty('/addrData'))    // addrData 가져옴
				//         console.log(this.byId("frgTable").getModel().getProperty('/addrData'))    // 위랑 똑같이 가져옴
				//      console.log(this.byId("frgTable").getModel().getProperty('/addrData/ADDRLST'))   
				//         console.log(selectedRow)  // row 라인 가져옴  첫번째 : 0 두번째 : 1 세번째 : 2
				//          console.log(aa[selectedRow]);   // ADDRLST에서 선택한 행 값 가져옴

				/*model.setData(data);

				this.getView().setModel(model);*/
			},

			onPress: function () {
				var oView = this.getView();
				var self = this;

				if (!this.byId("ListDialog")) {
					Fragment.load({
						id: oView.getId(),
						name: "SmartBrewer.RegistProject.view.order.menu.Image",
						controller: self
					}).then(function (oDialog) {
						oView.addDependent(oDialog);
						oDialog.open();
					})
				} else {
					this.byId('ListDialog').open();
				}
			},
			onSavefrg: function (oEvent) {
				var msg = '이미지를 불러왔습니다.';
				MessageToast.show(msg);

				var sImageSrc = this.getView().byId('preview').getSrc();
				this.getView().byId('LabelImage').setValue(sImageSrc);

				this.byId("ListDialog").close();
				this.byId("ListDialog").destroy();

			},
			Imgupload: function (oEvent) {
				let localFile = oEvent.getParameter('files')[0];
				var jsonData = {
					layoutData: {}
				};
				var oModel = new JSONModel();
				console.log(localFile);
				this.getOwnerComponent().setModel(oModel);
				this.getOwnerComponent().getModel().setData(jsonData);
				this.getOwnerComponent().getModel().setProperty('/layoutData/file', localFile);
				console.log(this.getOwnerComponent().getModel());
				let reader = new FileReader();
				let self = this;
				reader.readAsDataURL(localFile);
				reader.onload = function () {
					console.log(reader);
					self.getOwnerComponent().getModel().setProperty('/layoutData/imageUrl', reader.result);
					self.img();
				};
			},

			img: function () {
				var self = this;
				var form = new FormData();
				var file = this.getOwnerComponent().getModel().getProperty('/layoutData/file');
				console.log(file);
				form.append("image", file);

				$.ajax({
					url: 'https://api.imgur.com/3/image/',
					method: "POST",
					crossDomain: true,
					headers: {
						Authorization: "Client-ID 22f626626686a62",
						Accept: 'application/json'
					},
					mimeType: 'multipart/form-data',
					contentType: false,
					processData: false,
					data: form,
					success: function (res) {
						console.log(JSON.parse(res).data.link);
						imglnk = JSON.parse(res).data.link;
						self.getView().byId('preview').setSrc(imglnk);
						self.getView().byId('LabelImage').setValue(imglnk);
					}
				})
			},

			onExit: function () {
				console.log(this);
				this.byId("ListDialog").close();
				this.byId("ListDialog").destroy();

			},

			labelPress: function (oEvent) {
				this.byId('preview').setSrc(oEvent.getSource().getSrc());
				// this.byId('preview').setSrc(oEvent.getSource().getTileContent().getImageContent().getSrc());
			},

			phoneRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				// 필드 입력한 내용
				var regExp = /(01[016789])-([1-9]{1}[0-9]{2,3})-([0-9]{4})$/;
				var sState = regExp.test(newValue) ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},
			WaterAmountRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var sState = newValue >= 50 && (newValue % 10) == 0 ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},
			YeastAmountRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var sState = newValue < 10 ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},
			NurukAmountRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var sState = newValue >= 50 ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},
			RiceAmountRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var sState = newValue >= 1 ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},
			SugarAmountRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var sState = newValue <= 1000 ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},

			AlcAmountRuleCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var sState = newValue <= 19 ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}
			},
			TempRuleCheck: function (oEvent) {

				var newValue = oEvent.getSource().getValue();
				var sState = newValue <= 32 ? "None" : "Warning";
				oEvent.getSource().setValueState(sState);
				if (sState === "Warning") {
					err_flag = true;
				} else {
					err_flag = false;
				}

			},
			priceCheck: function (oEvent) {
				var newValue = oEvent.getSource().getValue();
				var priceValue = $("[name='PriceInput']").first()
				var sState = newValue * 10000;
				priceValue.val(sState);
			}

		});
	});