sap.ui.define(
	['SmartBrewer/RegistProject/controller/BaseController', 'sap/ui/model/json/JSONModel',
		"sap/ui/VersionInfo", "sap/ui/core/mvc/XMLView",
		'jquery.sap.global', 'sap/ui/core/Fragment',
		'sap/ui/core/mvc/Controller', 'sap/ui/model/Filter', 'sap/m/MessageToast',
		'sap/m/MessageBox'
	],
	function (BaseController, JSONModel, VersionInfo, XMLView,
		jQuery, Fragment, Controller, Filter, MessageToast, MessageBox) {
		"use strict";

		var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";
		return BaseController.extend("SmartBrewer.RegistProject.controller.order.menu.RecipeOrder", {

			onInit: function () {
				var self = this;
				if (sap.ui.getCore().getModel() === undefined) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.show(
						'주문 세션이 만료되었습니다.', {
							title: "세션 만료",
							actions: [sap.m.MessageBox.Action.CLOSE],
							styleClass: bCompact ? "sapUiSizeCompact" : "",
							onClose: function (sAction) {
								self.getRouter().navTo("productlist");
							}
						}
					);
				}
			},

			getData: function () {

				var self = this;

				var I_DATA = [{
					//       "PROJID": 
					USERID: self.getUserId(),
					DELVAD: self.byId("AddressInput").getValue(),
					DELVDE: self.byId("AdressDetailInput").getValue(),
					DELVPO: self.byId("AdressNumberInput").getValue(),
					DELVRC: self.byId("RecipientInput").getValue(),
					DELVRE: self.byId("DeliveryRequirementInput").getValue(),
					ORDEMO: self.byId("VolumeOfOrdersInput").getValue(),
					ORDEPR: self.byId("PriceInput").getValue(),
					RCTOBN: self.byId("phoneNumberInput").getValue(),
					RCTELC: self.byId("NumberInput").getValue()

				}];

				$.ajax({
					url: rfc_url,
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_PROJID: I_PROJID,
							I_USERID: I_USERID,
							I_DELVAD: I_DELVAD,
							I_DELVDE: I_DELVDE,
							I_DELVPO: I_DELVPO,
							I_DELVRC: I_DELVRC,
							I_ADDREQ: I_ADDREQ,
							I_RCTELC: I_RCTELC,
							I_RCMOBN: I_RCMOBN,
							I_ORDEMO: I_ORDEMO,
							I_ORDEPR: I_ORDEPR,
						},
						function: "ZB_GET_RECIPE"
					}),
					dataType: 'json',
					success: function (res) {
						let Msg = res.exportData.E_MSG;

						MessageToast.show(Msg);
					},
					error: function (e) {
						oDialog.close();
					}
				});
			},

			onCheck: function (oEvent) {

				var self = this;
				var projid = sap.ui.getCore().getModel().getProperty('/projid');
				var ordemo = self.getView().byId("VolumeOfOrdersInput").getValue();
				var prespr = self.getOwnerComponent().getModel().getProperty('/PageData').E_PRESPR;

				console.log(sap.ui.getCore().getModel().getProperty('/projid'), this, self.getView().byId("AddressInput").getValue())
				$.ajax({
					url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
					type: 'POST',
					contentType: 'application/json',
					data: JSON.stringify({
						importData: {
							I_PROJID: sap.ui.getCore().getModel().getProperty('/projid'),
							I_USERID: self.getUserId(),
							I_DELVAD: self.getView().byId("AddressInput").getValue(),
							I_DELVDE: self.getView().byId("AdressDetailInput").getValue(),
							I_DELVPO: self.getView().byId("AdressNumberInput").getValue(),
							I_ADDREQ: self.getView().byId("DeliveryRequirementInput").getValue(),
							I_DELVRC: self.getView().byId("RecipientInput").getValue(),
							I_RCTELC: self.getView().byId("NumberInput").getValue(),
							I_RCMOBN: self.getView().byId("phoneNumberInput").getValue(),
							I_ORDEMO: ordemo,
							I_ORDEPR: (ordemo * prespr)
						},
						function: "ZB_GET_RECIPE"
					}),
					dataType: 'json',
					success: function (res) {
						console.log(res);
						var RecipeOrder = {
							E_MSG: res.exportData.E_MSG,
							E_CODE: res.exportData.E_CODE,

						};
						self.getModel().setProperty('/RecipeOrder', RecipeOrder);
						var bCompact = !!self.getView().$().closest(".sapUiSizeCompact").length;
						//정상 주문 체크 논리 필요
						sap.m.MessageBox.show(
							'주문이 완료되었습니다.', {
								title: "주문완료",
								actions: [sap.m.MessageBox.Action.CLOSE],
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								onClose: function (sAction) {
									self.getRouter().navTo("productlist");
									window.location.reload();
								}
							}
						);
					},
					error: function (e) {
						MessageToast.show(e);
					}
				});

			},

			onOpenDialog: function (oEvnet) {

				var oModel = new JSONModel()
				var oView = this.getView();
				var self = this;
				if (!this.byId("addrSelect")) {
					Fragment.load({
						id: oView.getId(),
						name: "SmartBrewer.RegistProject.view.order.menu.AddrSelect",
						controller: this
					}).then(function (oDialog) {
						// connect dialog to the root view of this component (models, lifecycle)

						oView.addDependent(oDialog);
						oDialog.open();

					});
					var oModel = new JSONModel()

					let jsonData = {
						rfcData: {
							E_ADDRNM: [],
							E_ADDRPO: [],
							E_ADDRAD: [],
							E_RESULT: [],
							E_MSG: []
						},
						layoutData: {}
					};
					$.ajax({
						url: "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute",
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify({
							importData: {
								I_USERID: self.getUserId()
							},
							function: "ZB_GET_ADDR",
						}),
						dataType: 'json',
						success: function (res) {

							var addrData = {
								ADDRLST: res.exportData.T_ZBSDS0020
							}
							self.getView().getModel().setProperty('/addrData', addrData);

							// this.setModel(oModel, "Addrlist");

						},
						error: function (e) {
							MessageToast.show(e);
						}
					});

				} else {
					this.byId("addrSelect").open();
				}

			},

			onOpenDialog2: function (oEvnet) {
				var oModel = new JSONModel()
				var oView = this.getView();
				var self = this;
				if (!this.byId("addrInput")) {
					Fragment.load({
						id: oView.getId(),
						name: "SmartBrewer.RegistProject.view.order.menu.AddrInput",
						controller: this
					}).then(function (oDialog) {
						// connect dialog to the root view of this component (models, lifecycle)

						oView.addDependent(oDialog);
						oDialog.open();

					})
				} else {
					this.byId("Addr").open();
				}

			},
			onSearch: function (page) {
				var oModel = new JSONModel()
				var oView = this.getView();
				var self = this;
				$.ajax({
					url: "https://www.juso.go.kr/addrlink/addrLinkApiJsonp.do",
					type: "post",
					data: {
						resultType: 'json',
						returnUrl: 'https://webidecp-z1zug0uysb.dispatcher.jp1.hana.ondemand.com/', //호출한 화면 (AddrInput.fragment.xml 주소)
						currentPage: page,
						countPerPage: 10,
						keyword: self.byId('input0').getValue(),
						//'체육관로',
						currentPageRoad: page,
						countPerPageRoad: 10,
						resultTypeRoad: 'json',
						keywordRoad: self.byId('input0').getValue(),
						//'체육관로',
						roadAddr: '',
						bdNm: '',
						roadAddrPart1: '',
						bdKdcd: '',
						roadAddrPart2: '',
						siNm: '',
						engAddr: '',
						sggNm: '',
						jibunAddr: '',
						emdNm: '',
						zipNo: '',
						liNm: '',
						admCd: '',
						rn: '',
						rnMgtSn: '',
						udrtYn: '',
						bdMgtSn: '',
						buldMnnm: '',
						buldSlno: '',
						detBdNmList: '',
						mtYn: '',
						emdNo: '',
						lnbrMnnm: '',
						lnbrSlno: '',
						confmKey: 'devU01TX0FVVEgyMDE5MTEwOTE2NDU0NTEwOTE4MDg='
							//'devU01TX0FVVEgyMDE5MTEwODE5MDYzMzEwOTE3OTk='          //  집에꺼    이거 자리 옮기면 다시 신청해서 받아야함 
							//'devU01TX0FVVEgyMDE5MTEwODE3MzA0NzEwOTE3OTc=',        //학교내자리        // https://www.juso.go.kr/addrlink/devAddrLinkRequestWrite.do?returnFn=write&cntcMenu=URL
					}, // 여기 사이트로 들어가서 신청하면 바로 받아짐
					dataType: "jsonp",
					success: function (jsonStr) {
						self.getView().getModel().setProperty('/jsonStr', jsonStr);

						var addrData = {
							ADDRLST: self.byId("table0").getModel().getProperty('/jsonStr/results/juso')
						}
						self.getView().getModel().setProperty('/addrData', addrData);

						//       roadAddr: "부산광역시 서구 망양로 231 (동대신동1가, 혜광주택)"
						//       roadAddrPart1: "부산광역시 서구 망양로 231"
						//       zipNo: "49214"  우편번호
						//       console.log(self.getView().getModel().getProperty('/jsonStr/results/juso/0/emdNm')) // 여기서 찾아짐
					},
					error: function (xhr, status, error) {
						alert("에러발생");
					}
				});
			},
			onClose2: function () {
				this.byId("Addr").close();
				this.byId("Addr").destroy();
			},
			onOK2: function (oEvent) {
				var self = this;
				var selectedRow = self.getView().byId("table0").getSelectedIndices();
				var addrData = {
					ADDRLST: [{
						ADDRAD: self.byId("table0").getModel().getProperty('/jsonStr/results/juso')[selectedRow[0]].roadAddr,
						ADDRPO: self.byId("table0").getModel().getProperty('/jsonStr/results/juso')[selectedRow[0]].zipNo
					}]
				};

				self.getModel().setProperty('/addrData', addrData);

				//       self.getView().setModel(oModel, 'jsonData');

				console.log(addrData)
				console.log(self.byId("table0").getModel().getProperty('/addrData'))

				var selectAddr = self.byId("table0").getModel().getProperty('/addrData/ADDRLST');
				console.log(selectAddr)
				self.getView().getModel().setProperty('/selectData', selectAddr[0]);
				console.log(selectAddr[0])
				this.byId("Addr").close();
				this.byId("Addr").destroy();
			},

			onOk: function (oEvent) {

				this.byId("addrSelect").getModel().getProperty('/addrData');
				var selectedRow = this.getView().byId("frgTable").getSelectedIndices();
				var aa = this.byId("frgTable").getModel().getProperty('/addrData/ADDRLST');
				this.getView().getModel().setProperty('/selectData', aa[selectedRow]);

				this.byId("addrSelect").close();

			},

			onClose: function () {

				this.byId("addrSelect").close();

			},

			/*   handleUploadPress: function (oEvent) {
			      var oView2 = this.getView(),
			         self = this;

			      if (!this._oDialog) {
			         Fragment.load({
			            id: oView2.getId(),
			            name: "SmartBrewer.RegistProject.view.order.Image",
			         }).then(function (oDialog) {
			            self._oDialog = oDialog;
			            oView2.addDependent(oDialog);
			            oDialog.open();
			         });
			      } else {
			         this._oDialog.open();
			      }
			   },*/
			// 추천 레시피 라벨 이미지도 고정이야 ?
			priceCheck: function (oEvent) {
				var self = this;
				var newValue = oEvent.getSource().getValue();
				var priceValue = $("[name='PriceInput']").first()
				var pr = self.getOwnerComponent().getModel().getProperty('/PageData').E_PRESPR;
				var sState = (newValue * pr);
				// priceValue.val(sState);
				priceValue.val(sState);

			}
		});
	});