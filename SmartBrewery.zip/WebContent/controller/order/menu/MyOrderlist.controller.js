sap.ui.define([
      'SmartBrewer/RegistProject/controller/BaseController',
      'sap/ui/model/json/JSONModel',
      "sap/ui/VersionInfo",
      "sap/ui/core/mvc/XMLView",
      'jquery.sap.global',
      'sap/ui/core/Fragment',
      'sap/ui/core/mvc/Controller',
      'sap/ui/model/Filter',
      'sap/m/MessageToast',
      'sap/ui/model/FilterOperator'
   ],
   function (BaseController, JSONModel, VersionInfo, XMLView,
      jQuery, Fragment, Controller, Filter, MessageToast, FilterOperator) {
      "use strict";
      var asstt;
      var asend;
      var oListModel = new JSONModel();
      var oDetailModel = new JSONModel();
      var rfc_url = "https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute";
      return BaseController.extend("SmartBrewer.RegistProject.controller.order.menu.MyOrderlist", {

         onInit: function () {
            var oModel = new JSONModel()
            var self = this;
            var jsonData = {};

            this.getView().setModel(oModel, "oModel");
            this.getView().getModel("oModel").setData(jsonData);

            $.ajax({
               url: rfc_url,
               type: 'POST',
               contentType: 'application/json',
               data: JSON.stringify({
                  importData: {
                     I_USERID: self.getUserId()
                  },
                  function: "ZB_ORDER_LIST",
               }),
               dataType: 'json',
               success: function (res) {
                  console.log(oModel);
                  console.log(res.exportData);
                  var oModel = new JSONModel(res.exportData);
                  self.setModel(oModel, "Orderlist");
               },
               error: function (e) {
                  MessageToast.show(e);
               }
            })

         },

         changeORDEID: function (oEvent) {
            let ORDEID = oEvent.getSource().getValue()
            console.log('change')
            console.log(ordeid)
            this.getView().getModel().setProperty('/layoutData/I_ORDEID', ordeid)
         },

         changeORDENO: function (oEvent) {
            let ORDENO = oEvent.getSource().getValue()
            console.log('change')
            console.log(ordeno)
            this.getView().getModel().setProperty('/layoutData/I_ORDENO', ordeno)
         },

         getList: function (oEvent) {
            var oItem = oEvent.getSource().getBindingContext("Orderlist").getPath();
            console.log("oItem" + oItem)
            var ordeid = oEvent.getSource().getBindingContext("Orderlist").getModel().getProperty(oItem + "/ORDEID");
            console.log(ordeid);
            var ordeno = oEvent.getSource().getBindingContext("Orderlist").getModel().getProperty(oItem + "/ORDENO");
            console.log(ordeno);

            var self = this;
            self.getOwnerComponent().setModel(new JSONModel({
               layoutData: {
                  ordeid,
                  ordeno
               }
            }), "test");

            $.ajax({
               url: 'https://springbootsample2z1zug0uysb.jp1.hana.ondemand.com/spring-boot-rfc-0.0.1-SNAPSHOT/rfc/execute',
               type: 'POST',
               contentType: 'application/json',
               data: JSON.stringify({
                  importData: {
                     "I_ORDEID": ordeid,
                     "I_ORDENO": ordeno,
                  },
                  function: "ZB_SD_DETAIL_SEARCH"
               }),
               dataType: 'json',
               success: function (res) {
                  console.log(res);
                  self.getOwnerComponent().setModel(new JSONModel(res.exportData), "detailModel");
               },
               error: function (e) {
                  console.log(e);
               }
            });
            this.getOwnerComponent().getTargets().display("myorderdetail");
         }
      });
   });