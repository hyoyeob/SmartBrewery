sap.ui.define(['SmartBrewer/RegistProject/controller/BaseController', 'sap/ui/model/json/JSONModel',
	'sap/ui/Device', 'SmartBrewer/RegistProject/model/formatter',
	'sap/m/Link', 'sap/m/MessageToast', 'sap/ui/core/mvc/Controller',
	'sap/m/Button', 'sap/ui/core/CustomData', "sap/ui/VersionInfo",
	"sap/ui/core/mvc/XMLView"
], function (BaseController, JSONModel,
	Device, formatter, Link, MessageToast, Controller, Button, CustomData, VersionInfo, XMLView) {
	"use strict";
	return BaseController.extend("SmartBrewer.RegistProject.controller.order.Order", {
		formatter: formatter,

		onInit: function () {},
		action: function (oEvent) {},
		onItemSelect: function (oEvent) {
			var key = oEvent.getSource().data('itemKey'),
				oOwner = this.getOwnerComponent();
				console.log(key);
			if (oOwner) {
				oOwner.getRouter().navTo(key);
			}
		}
	});
});