sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"SmartBrewer/RegistProject/model/models",
	"sap/ui/core/routing/History",
	"sap/ui/model/resource/ResourceModel"
], function (UIComponent, Device, models, History) {
	"use strict";

	return UIComponent.extend("SmartBrewer.RegistProject.Component", {
		metadata: {
			manifest: "json"
		},
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			this.setModel(new sap.ui.model.json.JSONModel(), "uiControl");
			
		},

		myNavBack: function () {
			var oHistory = History.getInstance();
			var oPrevHash = oHistory.getPreviousHash();
			if (oPrevHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("masterSettings", {}, true);
			}
		},

		getContentDensityClass: function () {
			if (!this._sContentDensityClass) {
				if (!sap.ui.Device.support.touch){
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		}
	});
});