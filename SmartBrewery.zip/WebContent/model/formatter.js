sap.ui.define([
	"sap/base/strings/formatMessage"
], function (formatMessage) {
	"use strict";

	return {
		formatMessage: formatMessage,
		srcImageValue: function (bIsPhone) {
			var sImageSrc = "";
			if (bIsPhone === false) {
				sImageSrc = "./images/homeImage.jpg";
			} else {
				sImageSrc = "./images/homeImage_small.jpg";
			}
			return sImageSrc;
		},

		/*게시글 승인 여부 한글로 변환하는 로직*/
		fundingCheck: function (check) {
			switch (check) {
			case "R":
				return "승인 대기";
			case "W":
				return "작성 중";
			case "D":
				return "미 승인";
			case "A":
				return "승인";
			}
		},
		useynState3: function (oVALST) {

			if (oVALST === "정상") {
				return "Success";
			} else {
				return "Error";
			}
		},
		fundingCheckk: function (check) {
			switch (check) {
			case "A":
				return "진행 중";
			case "B":
				return "실패";
			case "C":
				return "완료";
			case "D":
				return "미 진행";
			}
		},
		// 가용 상태 색깔
		useynState: function (oUSEYN) {

			if (oUSEYN === "X") {
				return "Warning";
			} else {
				return "Success";
				// Success: 초록 Warning: 노랑 Error: 빨강
			}
		},

		// 가용상태 문자: 가용 중, 사용 가능
		useynText: function (oUSEYN) {
			var ResourceBundle = this.getModel("i18n").getResourceBundle();

			if (oUSEYN === "X") {
				return "가동 중";
			} else {
				return "가동 가능";
			}
		},

		useynState2: function (oUSEYN) {

			if (oUSEYN === "X") {
				return "sap-icon://color-fill";
			} else {
				return " ";
			}
		}
	};
});